package main
import (
    "fmt"
    "math"
    "math/rand"
    "math/cmplx"
    "runtime"
    "time"
)
func add(x int, y int) int {
    return x + y
}
func swap(x, y string) (string, string) {
    return y, x
}
func split(sum int) (x, y int) {
    x = sum * 4 / 9
    y = sum - x
    return
}

func needInt(x int) int { 
    return x*10 + 1 
}
func needFloat(x float64) float64 {
    return x * 0.1
}

func sqrt(x float64) string {
    if x < 0 {
        return sqrt(-x) + "i"
    }
    return fmt.Sprint(math.Sqrt(x))
}


func pow(x, n, lim float64) float64 {//3,2,10 => 9
    if v := math.Pow(x, n); v < lim {
        return v
    }
    return lim
}


func pow1(x, n, lim float64) float64 {
    if v := math.Pow(x, n); v < lim {
        return v
    } else {
        fmt.Printf("%g >= %g\n", v, lim)
    }
    // fmt.Printf(v) 这里V会报错
    // 这里开始就不能使用 v 了
    return lim
}





func SqrtMine(x float64) float64 {
    z := float64(1);
    for {
        tmp := z - (z*z-x)/(2*z)
        // fmt.Println(tmp)
        if tmp == z || math.Abs(tmp-z) < 0.000000000001 {
            break
        }
        z = tmp
    }
    return z
}











var c, python, java bool
var i int

func main() {
    fmt.Println("Hello, World!")
    fmt.Println("My favorite number is", rand.Intn(100))
    fmt.Println(math.Pi)
    fmt.Printf("Now you have %g problems.", math.Nextafter(2, 3))

    a, b := swap("Zhou", "Zhang")
    fmt.Println(a, b)
    fmt.Println(split(9))


    fmt.Println(i, c, python, java)

    var i, j int = 1, 2
    var c, python, java = true, false, "no!" //等价于 c, python, java := true, false, "no!"
    fmt.Println(i, j, c, python, java)

    k := 3
    fmt.Println(i, j, k, c, python, java)

    var (
        ToBe   bool       = false
        MaxInt uint64     = 1<<64 - 1
        z      complex128 = cmplx.Sqrt(-5 + 12i)
    );
    const f = "%T(%v)\n"
    fmt.Printf(f, ToBe, ToBe)
    fmt.Printf(f, MaxInt, MaxInt)
    fmt.Printf(f, z, z)

    var i1 int
    var f1 float64
    var b1 bool
    var s1 string
    fmt.Printf("%v %v %v %q\n", i1, f1, b1, s1)

    var i2 int = 42 //i2 := 42
    var f2 float64 = float64(i2) //f2 := float64(i2)
    var u2 uint = uint(f2) //u := uint(f2)

    fmt.Println(i2, f2, u2)

    var x3, y3 int = 3, 4
    var f3 float64 = math.Sqrt(float64(x3*x3 + y3*y3))
    var z3 int = int(f3)
    fmt.Println(x3, y3, z3)//3,4,5


    v := 0.867 + 0.5i //42 3.142  0.867 + 0.5i change me!
    fmt.Printf("v is of type %T\n", v)
    

    /*
    常量
    常量的定义与变量类似，只不过使用 const 关键字。 

    常量可以是字符、字符串、布尔或数字类型的值。

    常量不能使用 := 语法定义。
    */
    const (
        Big   = 1 << 100
        Small = Big >> 99
    );

    const Pi = 3.14
    const World = "世界"
    const Truth = true

    fmt.Println("Hello", World)
    
    fmt.Println("Happy", Pi, "Day")

    fmt.Println("Go rules?", Truth)

    fmt.Println(needInt(Small))//21
    fmt.Println(needFloat(Small))//0.2
    fmt.Println(needFloat(Big))//1.2676506002282295e+29
    /*
    for
    Go 只有一种循环结构——`for` 循环。

    基本的 for 循环除了没有了 `( )` 之外（甚至强制不能使用它们），看起来跟 C 或者 Java 中做的一样，而 `{ }` 是必须的。
    */
    sum1 := 0
    for i := 0; i < 10; i++ {
        sum1 += i
    }
    fmt.Println(sum1)
    /*for（续） 跟 C 或者 Java 中一样，可以让前置、后置语句为空。*/
    /*or 是 Go 的 “while” 基于此可以省略分号：C 的 while 在 Go 中叫做 `for`。*/
    sum2 := 1
    for sum2 < 1000 {
        sum2 += sum2
    }
    fmt.Println(sum2)
    /*死循环
    如果省略了循环条件，循环就不会结束，因此可以用更简洁地形式表达死循环。
    for {
    }
    */ 
    /*if
    if 语句除了没有了 `( )` 之外（甚至强制不能使用它们），看起来跟 C 或者 Java 中的一样，而 `{ }` 是必须的。*/
 
    fmt.Println(sqrt(2), sqrt(-4))


    fmt.Println(
        math.Pow(3, 2),//3的平方
        pow(3, 2, 10),
        pow(3, 3, 20),
    )
    fmt.Println(
        math.Pow(3, 2),//3的平方
        pow1(3, 2, 10),
        pow1(3, 3, 20),
    )

    fmt.Println("HelloSqrtMine")

    fmt.Println(SqrtMine(3))

    fmt.Println("HelloSqrt")
    fmt.Println(math.Sqrt(3))

    //switch
    fmt.Print("Go runs on ")
    switch os := runtime.GOOS; os {//一个结构体（`struct`）就是一个字段的集合。除非以 fallthrough 语句结束，否则分支会自动终止。
        case "darwin":
            fmt.Println("OS X.")
        case "linux":
            fmt.Println("Linux.")
        default:
            // freebsd, openbsd,
            // plan9, windows...
            fmt.Printf("%s.", os)
    }

    fmt.Println("\nWhen's Saturday?")
    today := time.Now().Weekday()
    switch time.Saturday {//switch 的条件从上到下的执行，当匹配成功的时候停止。
        case today + 0:
            fmt.Println("Today.")
        case today + 1:
            fmt.Println("Tomorrow.")
        case today + 2:
            fmt.Println("In two days.")
        default:
            fmt.Println("Too far away.")
    }


    ti := time.Now()
    switch {//没有条件的 switch 同 `switch true` 一样。
        case ti.Hour() < 12:
            fmt.Println("Good morning!\n")
        case ti.Hour() < 17:
            fmt.Println("Good afternoon.\n")
        default:
            fmt.Println("Good evening.\n")
    }
    /*
    defer
    defer 语句会延迟函数的执行直到上层函数返回。

    延迟调用的参数会立刻生成，但是在上层函数返回前函数都不会被调用。
    */
    defer fmt.Println("world")

    fmt.Println("hello defer")

    //defer 栈 延迟的函数调用被压入一个栈中。当函数返回时， 会按照后进先出的顺序调用被延迟的函数调用。
    fmt.Println("counting")

    for i := 0; i < 10; i++ {
        defer fmt.Println(i)
    }

    fmt.Println("done")
}