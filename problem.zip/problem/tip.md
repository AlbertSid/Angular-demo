

[webkit所支持的最新API](https://webkit.org/status/)

## [WebAssembly/design(github地址)](https://github.com/WebAssembly/design)

WebAssembly 目前可以通过 Emscripten SDK 生成

WebAssembly的宗旨很容易理解：“一种全新的跨浏览器Web中间表示层安全代码，为未来浏览器带来一种可执行的标准二进制数据格式，使得越来越多的开发者，不仅仅是JavaScript开发者，甚至是Rust,C#,Go语言的开发者，借助统一的编译机制，预先将这些语言开发的逻辑编译为浏览器可以执行的二进制代码格式，以此提高Web内容的性能和表现能力，同时为更多语言的开发者提供一种为Web开发内容的有效途径。”

在目前阶段，WebAssembly 不适合直接编写具体的业务逻辑，而更适合编写应用程序中对性能要求比较高的库，并与 JavaScript 编写的业务逻辑进行通讯，并在 JavaScript 端对 DOM 节点进行操作。
在目前阶段，WebAssembly 适合大量密集计算、并且无需频繁与 JavaScript 及 DOM 进行数据通讯的场景。比如游戏渲染引擎、物理引擎、图像音频视频处理编辑、加密算法等。

现在的Web领域：[ES, Ts, Dart, Coffee, ... ] => Javascript => Browser
未来猜测：[ES, Ts, 真•Js2.0, C, Go, ... ] => WebAssembly => Browser

微软、Google、Mozilla 都觉得 JS 各种不好，为了各自的目的分别推出了各自的 JS 替代品（TypeScript、Dart、ASM.js）。

[WebAssembly火狐API文档](https://developer.mozilla.org/zh-CN/docs/WebAssembly)
[webassembly-in-browsers](https://blog.mozilla.org/blog/2017/11/13/webassembly-in-browsers/)
[WasmExplorer在线编辑](https://mbebenita.github.io/WasmExplorer/)
[blog.mozilla](https://blog.mozilla.org/)
[developer.mozilla](https://developer.mozilla.org/zh-CN/)
[加密](https://github.com/asmcrypto/asmcrypto.js)
[计算代数](http://mathstud.io/)
[物理模拟](https://github.com/kripken/ammo.js/)
[联合mputer愿景](https://hacks.mozilla.org/2017/09/bootcamps-webassembly-and-computer-vision/)
[Altus平台](http://releases.ba3.us/latest/)
[Google地球](https://medium.com/google-earth/earth-on-web-the-road-to-cross-browser-7338e0f46278)
[用户界面设计](https://blog.figma.com/webassembly-cut-figmas-load-time-by-3x-76f3f2395164)
[语言监测](https://github.com/jaukia/cld-js)
[音频混合](http://eecs.qmul.ac.uk/~keno/60.pdf)
[视频编解码器支持](https://github.com/brion/ogv.js/)
[数字信号处理](https://github.com/shamadee/web-dsp)
[医学影像](https://github.com/jodogne/wasm-dicom-parser)

## [Progressive Web App](https://zhuanlan.zhihu.com/p/25167289)
一种web流应用
[Progressive](https://developers.google.com/web/)
[Progressive官网](https://developers.google.com/web/progressive-web-apps/)
[Progressive-demo](https://codelabs.developers.google.com/codelabs/your-first-pwapp/#0)
[Progressive知乎](https://www.zhihu.com/question/46690207)
[您的第一个 Progressive Web App](https://developers.google.com/web/fundamentals/codelabs/your-first-pwapp/?hl=zh-cn)



## [A 5-minute Intro to Styled Components](https://medium.freecodecamp.org/a-5-minute-intro-to-styled-components-41f40eb7cd55)
like CSS-in-JS
[styled-components 官网](https://www.styled-components.com/)
[styled-components goup](https://github.com/styled-components)
[styled-components github](https://github.com/styled-components/styled-components)
[Vulcan](https://github.com/VulcanJS/Vulcan/tree/devel)
[medium styled-components](https://medium.com/styled-components)
[服务器端渲染简单指南React with styled-components](https://medium.com/styled-components/the-simple-guide-to-server-side-rendering-react-with-styled-components-d31c6b2b8fbf)

打包工具
## [rollup](https://github.com/rollup/rollup)
[rollup中文](http://www.rollupjs.com/)
## [parcel](https://github.com/parcel-bundler/parcel)
[parcel more](https://parceljs.org/)


## [flutter](https://github.com/flutter/flutter)
与react-native weex native类似，跨平台方案
[flutter -examples](https://github.com/flutter/flutter/tree/master/examples)
[flutter官网](https://flutter.io/)

## [GO 语言](https://github.com/astaxie/build-web-application-with-golang/tree/master/zh)

## [什么是REST](https://github.com/astaxie/build-web-application-with-golang/blob/master/zh/08.3.md)
一种数据模型
[REST 知乎](https://www.zhihu.com/question/28557115)
## [GraphQL](http://graphql.cn/)
GraphQL 是一个用于 API 的查询语言
[GraphQL中文规范](https://www.gitbook.com/book/wanglihui/graphql/details)
[GraphQL规范](http://facebook.github.io/graphql/October2016/)
[GitHub 为什么开放了一套 GraphQL 版本的 API](https://laravel-china.org/topics/3112/why-did-github-open-a-graphql-version-of-api)
[Node.js 服务端实践之 GraphQL 初探](http://taobaofed.org/blog/2015/11/26/graphql-basics-server-implementation/)
[深入理解 GraphQL](http://taobaofed.org/blog/2016/03/10/graphql-in-depth/)
[awesome-graphql](https://github.com/chentsulin/awesome-graphql)
[什么是GraphQL](http://blog.kazaff.me/2016/01/01/GraphQL%E4%BB%80%E4%B9%88%E9%AC%BC/)
[How to GraphQL 全栈教程网站](https://www.howtographql.com/)

[graphql-api-react-example](https://medium.com/@katopz/github-graphql-api-react-example-eace824d7b61)
**[reactql](https://reactql.org/)**
[react-starter-kit](https://github.com/kriasoft/react-starter-kit)
[graphql-js](https://github.com/graphql/graphql-js)
**[koa-graphql](https://github.com/chentsulin/koa-graphql)**
[graphql-demo](https://github.com/davidchang/graphql-pokedex-api)
**[relay](https://github.com/facebook/relay)**
[react-relay](https://www.npmjs.com/package/react-relay)
[graphql-relay](https://www.npmjs.com/package/graphql-relay)
[Your First GraphQL Server](https://medium.com/the-graphqlhub/your-first-graphql-server-3c766ab4f0a2)
[writing-a-basic-api-with-graphql](http://davidandsuzi.com/writing-a-basic-api-with-graphql/)
[relay-skeleton](https://github.com/fortruce/relay-skeleton)



## 其他
[pandora](http://www.midwayjs.org/pandora/zh-cn/) 一个Node.js 应用管理器
[inmap 可视化](https://github.com/TalkingData/inmap) 图表

以下是司徒正美开发的两个MVVM框架
[avalon](https://github.com/RubyLouvre/avalon)
[anu](https://github.com/RubyLouvre/anu)
[C++](http://www.learncpp.com/)


## openGL与webGL

OpenGL（全写Open Graphics Library）是个定义了一个跨编程语言、跨平台的编程接口的规格，它用于三维图象（二维的亦可）。OpenGL是个专业的图形程序接口，是一个功能强大，调用方便的底层图形库，是行业领域中最为广泛接纳的 2D/3D 图形 API，是个与硬件无关的软件接口，其自诞生至今已催生了各种计算机平台及设备上的数千优秀应用程序。

OpenGL使用简便，效率高。它具有七大功能：建模、变换、颜色模式设置、光照和材质设置、纹理映射(Texture Mapping)、位图显示和图象增强图象功能和双缓存动画(Double Buffering)。


OpenGL是一个开放的三维图形软件包，它独立于窗口系统和操作系统，以它为基础开发的应用程序可以十分方便地在各种平台间移植；OpenGL可以与Visual C++紧密接口，便于实现机械手的有关计算和图形算法，可保证算法的正确性和可靠性；OpenGL使用简便，效率高。它具有七大功能：

1. 建模：OpenGL图形库除了提供基本的点、线、多边形的绘制函数外，还提供了复杂的三维物体（球、锥、多面体、茶壶等）以及复杂曲线和曲面绘制函数。
2. 变换：OpenGL图形库的变换包括基本变换和投影变换。基本变换有平移、旋转、缩放、镜像四种变换，投影变换有平行投影（又称正射投影）和透视投 影两种变换。其变换方法有利于减少算法的运行时间，提高三维图形的显示速度。
3. 颜色模式设置：OpenGL颜色模式有两种，即RGBA模式和颜色索引（Color Index）。
4. 光照和材质设置：OpenGL光有自发光（Emitted Light）、环境光（Ambient Light）、漫反射光（Diffuse Light）和高光（Specular Light）。材质是用光反射率来表示。场景（Scene）中物体最终反映到人眼的颜色是光的红绿蓝分量与材质红绿蓝分量的反射率相乘后形成的颜色。
5. 纹理映射（Texture Mapping）。利用OpenGL纹理映射功能可以十分逼真地表达物体表面细节。
6. 位图显示和图象增强图象功能除了基本的拷贝和像素读写外，还提供融合（Blending）、抗锯齿（反走样）（Antialiasing）和雾（fog）的特殊图象效果处理。以上三条可使被仿真物更具真实感，增强图形显示的效果。
7. 双缓存动画（Double Buffering）双缓存即前台缓存和后台缓存，简言之，后台缓存计算场景、生成画面，前台缓存显示后台缓存已画好的画面。

此外，利用OpenGL还能实现深度暗示（Depth Cue）、运动模糊（Motion Blur）等特殊效果。从而实现了消隐算法。OpenGL设备运用，目前瑞芯微2918芯片和英伟达芯片Tegra2 就是采用OpenGL 2.0技术进行图形处理，而基于瑞芯微2918芯片方案代表是台电T760和微蜂X7平板电脑所采用到

[opengl英文网](https://www.opengl.org/)
[learnopengl-cn](https://learnopengl-cn.github.io/)
[learnopengl](https://learnopengl-cn.readthedocs.io/zh/latest/01%20Getting%20started/01%20OpenGL/)
[opengl](https://www.khronos.org/opengl)
[opengl-wiki](https://www.khronos.org/opengl/wiki/)
[opengles](https://www.khronos.org/opengles/)
[opengles.pdf](https://www.khronos.org/files/opengles_shading_language.pdf)
[第一个OpenGL程序](http://blog.csdn.net/candycat1992/article/details/39676669)

WebGL (Web图形库) 是一种JavaScript API，用于在任何兼容的Web浏览器中呈现交互式3D和2D图形，而无需使用插件。WebGL通过引入一个与OpenGL ES 2.0紧密相符合的API，可以在HTML5 <canvas> 元素中使用。

WebGL（全写Web Graphics Library）是一种3D绘图协议，这种绘图技术标准允许把JavaScript和OpenGL ES 2.0结合在一起，通过增加OpenGL ES 2.0的一个JavaScript绑定，WebGL可以为HTML5 Canvas提供硬件3D加速渲染，这样Web开发人员就可以借助系统显卡来在浏览器里更流畅地展示3D场景和模型了，还能创建复杂的导航和数据视觉化。显然，WebGL技术标准免去了开发网页专用渲染插件的麻烦，可被用于创建具有复杂3D结构的网站页面，甚至可以用来设计3D网页游戏等等。

WebGL仅仅是一个光栅化引擎，它可以根据你的代码绘制出点，线和三角形

[webgl 推荐看这个](https://webglfundamentals.org/webgl/lessons/zh_cn/)
[threejs](https://threejs.org/)
[红宝书 OpenGL Programming Guide，第八版](http://www.glprogramming.com/red/)
[threejs基础教程](http://www.hewebgl.com/article/getarticle/27)
[WebGL_API MOZ](https://developer.mozilla.org/zh-CN/docs/Web/API/WebGL_API)
[webgl-w3cschool](https://www.w3cschool.cn/webgl/vjxu1jt0.html)
[WebGL_learn](http://www.hiwebgl.com/?p=42)
[WebGL中文](http://www.hiwebgl.com/)
[WebGL基础](https://www.html5rocks.com/en/tutorials/webgl/webgl_fundamentals/)
[WebGL 技术经验分享](https://pan.baidu.com/share/link?uk=1023716385&shareid=354&fr=936379656&fa=936379656)
[learningwebgl](http://learningwebgl.com/blog/)
[WebGL_API Tutorial](https://developer.mozilla.org/zh-CN/docs/Web/API/WebGL_API/Tutorial)


相关资料
http://www.khronos.org/registry/webgl/specs/latest/
http://www.khronos.org/opengles/sdk/docs/man/
http://learningwebgl.com/blog/?page_id=1217
http://www.hiwebgl.com/?p=42
http://codeutopia.net/blog/2009/04/30/optimizing-javascript-for-extreme-performance-and-low-memory-consumption/

Demo
http://www.khronos.org/webgl/wiki/Demo_Repository
http://www.chromeexperiments.com/webgl
http://demo.oak3d.com
http://mrdoob.github.com/three.js/
http://www.hiwebgl.com/?cat=16


[谷歌人体模型](https://www.zygotebody.com/)
[谷歌地球](https://www.google.com/intl/zh-CN/earth/)
[谷歌火星](https://www.google.com/mars/)
[谷歌月球](https://www.google.com/moon/)
[谷歌星空](https://www.google.com/intl/zh-CN/sky/)


































