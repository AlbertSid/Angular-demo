[前端问题总汇](http://w3help.org/zh-cn/kb/)

浏览器内核
=============


	浏览器 | 内核（排版引擎）
	------------ | ------------- 
	Internet Explorer | Trident（又称为MSHTML），是微软开发的一种排版引擎；IE6、IE7、IE8（Trident 4.0）、IE9（Trident 5.0）、IE10（Trident 6.0）；
	Mozilla Firefox | Gecko是一套开放源代码的、以C++编写的网页排版引擎
	Netscape6 | Gecko
	Opera4-6 | Elektra排版引擎
	Opera7-12 | Presto
	Opera12+ | Blink
	Safari | Webkit引擎包含WebCore排版引擎（苹果公司开发）及JavaScriptCore解析引擎，均是从KDE的KHTML（基于KHTML内核的内核：WebKit、WebCore。）及KJS引擎衍生而来
	Chrome28以前 | Webkit
	Chrome28+ | Blink
	Mozilla Firefox 未来 | Servo



	浏览器 | JS引擎
	------------ | ------------- 
	Internet Explorer(8以前) | Jscript,VB Scrip
	Internet Explorer(9+) | Chakra
	Edge | Chakra
	Mozilla Firefox(1-3) | SpiderMonkey,Rhino
	Mozilla Firefox(3.5～3.6) | TraceMonkey。
	Mozilla Firefox(4+)| JaegerMonkey, IonMonkey
	Opera(4.0～6.1) | Linear A
	Opera(7.0～9.2) | Linear B
	Opera(9.5～10.2) | Futhark
	Opera(10.50～12) | Carakan
	Opera(12+) | V8
	Safari(4) | Nitro
	Safari | JavaScriptCore
	Chrome(28以前) | JavaScriptCore
	Chrome(28+) | v8
	Mozilla Firefox 未来 | Servo


	特点	 | SpiderMonkey  | 	JScript       | KJS
	------------ | ------------- |  ------------- | --------
	实现语言  | 	C  | 	C++  | 	C++
	执行模式  | 	解释执行  | 	解释执行  | 	解释执行
	解释器  | 	字节码解释器：基于栈的字节码  | 	字节码解释器：基于栈的字节码  | 	树遍历解释器
	自动内存管理  | 	mark-and-sweep  | 	mark-and-sweep  | 	mark-and-sweep
	对象布局 	 | ? 	 | 基本上是HashTable  | 	?
	针对密集数组的优化  | 	? 	 | 无 (JScript < 5.7）；有（JScript 5.8）  | 	?
	值表现形式  | 	tagged-value  | 	堆对象  | 	堆对象
	Function.prototype.toString()  | 	从字节码反编译 |  	?  | 	?


	SpiderMonkey 	KJS 	JavaScriptCore 	V8 	Managed JScript
	手写纯递归下降式 	bison生成LALR(1) 	bison生成的LALR(1) 	手写的递归下降+运算符优先级混合式 	手写的纯运算符优先级式 

 	
	V8 	SpiderMonkey 	Chakra 	Nitro 	Nashorn
	实现语言 	C++/汇编 	C++ 	C++ 	C++/汇编 	Java
	执行模式 	纯编译: 两层编译 	解释/编译混合式: 3层执行模式 	解释/编译混合: 2层执行模式，后台编译 	解释/编译混合: 3层执行模式 	纯编译
	解释器 	无 	字节码解释器 	字节码解释器：基于寄存器的字节码 	字节码解释器 LLInt：基于寄存器的字节码 	无
	动态编译器 	初级编译器 + 优化编译器 	初级编译器 Baseline + 优化编译器 IonMonkey 	有 	初级编译器 method JIT + 优化编译器 DFG JIT 	有
	自动内存管理 	分代式GC: 初生代: copying收集器; 年老代: 增量式mark-and-sweep, 可选compact 	分代式GC 	分代式GC: 初生代: copying收集; 年老代: 并发式mark-and-sweep 	分代式GC 	依赖于底层JVM的GC
	对象布局 	紧凑+隐藏类 Map 	紧凑+隐藏类 Shape 	紧凑+隐藏类 	紧凑+隐藏类 Structure 	紧凑+隐藏类 PropertyMap
	针对密集数组的优化 	有 	有 	有 	有 	有
	Inline-cache 	MIC/PIC 	PIC 	PIC 	PIC 	MIC/PIC
	值表现形式 	tagged-pointer / IEEE 754 double / integer 	pun-boxing 	tagged-value 	NaN-boxing 	  堆对象 / integer
	正则表达式 	编译 Irregexp 	编译 	编译 	编译 WREC 	混合
	Function. prototype. toString() 	保留源码原文 	(2012年7月前) 从字节码反编译; (761723后) 保留源码原文  	? 	? 	保留源码原文 


	Browser, Headless Browser, or Runtime 	JavaScript Engine
	Mozilla 	Spidermonkey
	Chrome 	V8
	Safari 	JavaScriptCore
	IE and Edge 	Chakra
	PhantomJS 	JavaScriptCore
	HTMLUnit 	Rhino
	TrifleJS 	V8
	Node.js 	V8
	Io.js* 	V8











# 为什么google浏览器和safari浏览器排序算法结果不一致


各浏览器使用的ECMAScript脚本引擎不同，导致对于 ECMAScript 相关规范细节实现并不一致。常见的浏览器以及脚本引擎如下表所示，此文将基于此表的脚本引擎常用名做描述。


'''
var ary = [2,5,6,1]
ary.sort(function(a,b){return a>b});
'''
当数组内元素个数小于等于 10 时：
JScript & Carakan 排序结果有误
Chakra & JavaScriptCore 看起来没有进行排序
IonMonkey 返回了预期的正确结果
V8 暂时看起来排序正确


'''
var ary = [7, 6, 5, 4, 3, 2, 1, 0, 10, 9, 8]
ary.sort(function(a,b){return a>b});
'''
当数组内元素个数大于 10 时：
JScript & Carakan 排序结果有误
Chakra & JavaScriptCore 看起来没有进行排序
IonMonkey 返回了预期的正确结果
V8 排序结果由正确转为不正确


单引擎多种排序实现
由于规范中并不要求引擎采用何种排序算法来实现 sort 函数。因此同一引擎对于所需排序元素总体数量不同，可能会采用不同的优化排序算方法。
V8 正是使用了这种多排序算法，参照 V8 : v8/src/array.js


返回值类型转为某种数值类型与 0 做比较
观看 JavaScriptCore 中此问题的具体实现， 参照 JavaScriptCore/runtime/JSArray.cpp


返回值转为符合规范的值范围
IonMonkey 引擎为何 TestCase 的排序结总符合预期呢？参照 Firefox : js/src/jsarray.cpp

解决方案
调用 Array.prototype.sort 函数并需要依赖 comparefn 处理排序结果时，应遵循规将 comparefn 函数返回值约束在 -1、0、1 范围内。



新的问题：
safari与google浏览器，火狐浏览器的在字符串非数字情况下排序的不一致的问题、、


	["h.plist","h.ipa"].sort()
	 这个在三个浏览器下结果一致。
	 但是
	["h.plist","h.ipa"].sort(function(){return 1})或出现不一致的情况?


	array.sort(function(array) {
	  var avg = array.reduce(function(previousValue, currentValue) {
	    return previousValue + currentValue;
	  }, 0);
	  avg /= array.length;
	  return function(x, y) {
	    return Math.abs(x - avg) - Math.abs(y - avg);
	  };
	}(array));
