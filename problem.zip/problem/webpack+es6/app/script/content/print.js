export default function print() {
  console.log('Updating print.js...')
}