什么叫精通XX语言, 我觉得应该有两种, 一种是精通在这种语言下实现对应业务的模式, 另一种是精通这门语言的规范, 不知道阁下所说的精通是哪种, 如果是前一种, 考核的重点不应该是在这种奇淫技巧上, 而是对对应岗位的技术栈的熟悉程度, 比如做数据可视化的要知道Canvas, SVG, WebGL, 做流媒体的要知道WebRTC, 等等; 如果是后一种, 我觉得国内99%的前端工程师都不敢说精通ECMA262 5.1规范, 知道 1 == [1] 的人, 不一定就真正知道其中的处理过程. 所以你所说的这是个有趣的面试题算是本末倒置了.



## Python
[isign - python](https://github.com/saucelabs/isign)
[aliyun-oss-python-sdk](https://help.aliyun.com/document_detail/32026.html?spm=5176.87240.400427.49.fi2hJK)
[aliyun-oss-python-sdk github](https://github.com/aliyun/aliyun-oss-python-sdk?spm=5176.doc32026.2.10.xpybzc)

[python——论坛](http://www.pythontab.com/)
[python——论坛](http://bbs.pythontab.com/)
[python——手册](http://docs.pythontab.com/)
[Python中文社区](https://zhuanlan.zhihu.com/zimei)
[Python中文社区](https://python-chinese.github.io/)
[Python中文社区](https://www.pyfor.com/)
[Python中文社区](https://pythoncaff.com/)
[Python中文社区](https://www.jianshu.com/u/b54fa5490d25)
[Python中文社区](http://www.python88.com/)


## webGL
[基于 HTML5 WebGL 的 3D 场景中的灯光效果](https://segmentfault.com/a/1190000012662222)
[hightopo,一套丰富的JavaScript界面类库](http://www.hightopo.com/)
[reason](https://reasonml.github.io/)
[reason-react](https://reasonml.github.io/reason-react/)
[H5 游戏开发：游戏引擎入门推荐](http://web.jobbole.com/93505/)


## Service_Worker
[Service_Worker_API](https://developer.mozilla.org/zh-CN/docs/Web/API/Service_Worker_API)
[Service_Worker](http://www.alloyteam.com/2016/01/9274/)
[service-workers](https://developers.google.com/web/fundamentals/primers/service-workers/?hl=zh-cn)

## 前端other
[nodejs-8.9-Api](http://nodejs.cn/api/assert.html)
[GoogleChrome 浏览器demo](https://github.com/GoogleChrome/samples)
[ajax安全](https://segmentfault.com/a/1190000012693772)
[JS深度解析](https://docs.google.com/presentation/d/1YVWcMjrqbUZBnITUaIlo6-uqGCo2Q6iHNg1uz8JDeGY/edit#slide=id.p4)
[chimee 一个视频组件](https://github.com/Chimeejs/chimee)
[staticgen静态资源网站](https://www.staticgen.com/)
[staticgen](https://github.com/netlify/staticgen)

[大漠css-layout](https://github.com/airen/css-layout)
[大漠CSS3](https://github.com/airen/CSS3)
[字体变体font-variation-](https://www.w3cplus.com/css3/font-variants.html)
[iCSS](https://github.com/chokcoco/iCSS)
[pell 编辑器](https://github.com/jaredreich/pell)
[前端通信](http://web.jobbole.com/93411/)
[GraphQL 搭配 Koa 最佳入门实践](https://juejin.im/post/5a49e5ccf265da430d585cfd)
[未来的前端工程师](https://juejin.im/post/5a474c8ff265da430a50ea57)
[2018年15大互联网趋势，你的技术方向走对了吗？](http://www.iteye.com/news/32843)
[2018前端值得关注的技术](https://segmentfault.com/a/1190000012740426)
[比特币白皮书：一种点对点的电子现金系统](http://www.8btc.com/wiki/bitcoin-a-peer-to-peer-electronic-cash-system)
[8款惊艳的HTML5粒子动画特效](http://www.iteye.com/news/32841)
[SegmentFault 年终盘点 - 2017 Top Rank](https://segmentfault.com/a/1190000012750528)
[文件上传](https://www.jianshu.com/p/46e6e03a0d53)
`<input type="file"  multiple name='file' />`
[鱼玄机](https://www.zhihu.com/question/23342835)
https://segmentfault.com/a/1190000012901505
## AI
*[tutorial](https://github.com/KeKe-Li/tutorial.git)*
*[AiLearning](https://github.com/geekhoo/AILearning)*
[入门机器学习](https://segmentfault.com/a/1190000012432435)
[tensorflow-tutorial-samples](https://github.com/gzdaijie/tensorflow-tutorial-samples)
[tensorflow-zh](https://github.com/jikexueyuanwiki/tensorflow-zh)

[machine-learning](https://www.coursera.org/learn/machine-learning)
[data-science](https://www.coursera.org/browse/data-science)

[AI数据 - COCO是一个大型的对象检测，分割和字幕数据集](http://cocodataset.org/#home)
[识别技术](https://www.ibm.com/watson/services/visual-recognition/)
[图像和视频识别API](https://www.clarifai.com/)
[深度学习和PowerAI开发](https://developer.ibm.com/linuxonpower/deep-learning-powerai/)
[用TensorFlow自定义对象检测](https://github.com/bourdakos1/Custom-Object-Detection)
[通过API实现人员智能](https://www.mturk.com/)
[RectLabel 一个图像标注工具，为边界框对象检测和分割标记图像。](https://rectlabel.com/)
[LabelImg是一个图形图像注释工具](https://github.com/tzutalin/labelImg)
[使用TensorFlow和Watson进行目标检测](https://medium.com/ibm-watson/dont-miss-your-target-object-detection-with-tensorflow-and-watson-488e24226ef3)
[用 TensorFlow 追踪千年隼号](https://zhuanlan.zhihu.com/p/31247372)
[最近 2 个月中我是如何开始学习 AI 的](https://zhuanlan.zhihu.com/p/30402049)
[2017-AI](https://zhuanlan.zhihu.com/p/32525291)
[2018-Ai](https://zhuanlan.zhihu.com/p/32556059)
[google CLOUD AI](https://cloud.google.com/products/machine-learning/)

[make.girls](http://make.girls.moe/#/)
[tensorflow-learning](https://morvanzhou.github.io/tutorials/machine-learning/tensorflow/)
[github.com/tensorflow](https://github.com/tensorflow)
[tensorfly.cn](http://www.tensorfly.cn/)
[tensorflow-zh](http://wiki.jikexueyuan.com/project/tensorflow-zh/)

[TensorFlow介绍与安装](https://www.jianshu.com/p/4c0c66a07c1f)
win安装tensorflow 方法 
`python -m pip install --upgrade https://storage.googleapis.com/tensorflow/mac/cpu/tensorflow-1.4.0-py2-none-any.whl`
`python -m pip install --upgrade https://storage.googleapis.com/tensorflow/windows/cpu/tensorflow-1.4.0-cp35-cp35m-win_amd64.whl`
`python -m pip install --upgrade https://storage.googleapis.com/tensorflow/windows/cpu/tensorflow_gpu-1.4.0-cp35-cp35m-win_amd64.whl`
`python -m pip list `等价于`pip2 list`
`python3 -m pip list `等价于`pip3 list`


[大数据与云计算学习：数据分析（一）](https://segmentfault.com/a/1190000011563943)


## 其他文章
[生命是什么](https://book.douban.com/subject/2061887/)
[生命是什么](https://www.zhihu.com/question/19551567)
生命的本质是一种负熵系统，是一个能够通过向外界环境摄入负熵从而避免自身系统同外界环境达成完全热平衡状态的系统。所谓的热平衡状态指的是区域内所有的物质达成了最无序的状态，也叫随机态。
[好的学习网站有哪些推荐？](https://www.zhihu.com/question/20396961)
[Mi2](http://news.china.com/yule/11184455/20170824/31175365_all.html)



