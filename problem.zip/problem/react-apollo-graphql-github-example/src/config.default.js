export const username = 'xxx'
export const password = 'xxx'
