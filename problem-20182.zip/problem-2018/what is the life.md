## Z,

MayBe life is replace.

　	一、
　　1、excuse(原谅) 2、me(我) 3、yes(是的) 4、is(动词现在时) 5、this(这) 6、your(你的，你们的)7、handbag(女用手提包) 8、pardon(原谅，请在说一遍) 9、it(它)10、thank you(感谢你) 11、very much(非常的) 12、pen(钢笔) 13、pencil(铅笔) 14、book(书) 15、watch(手表)(做动词时表示观看) 16、coat(大衣) 17、dress(连衣裙或套裙) 18、skirt(裙子) 19、shirt(衬衣) 20、car(小汽车) 21、house(房子)

　　二、
　　1、umbrella(伞) 2、please(请) 3、here(这里) 4、my(我的) 5、ticket(票) 6、number(号码) 7、sorry(对不起) 8、sir(先生) 9、cloakroom(衣帽存放出) 10、suit(一套衣服) 11、school(学校) 12、teacher(老师) 13、son(儿子) 14、daughter(女儿)

　　三、
　　1、mr(先生) 2、good(好) 3、morning(早晨)

　　4、miss(小姐) 5、new(新的) 6、student(学生)

　　7、french(法国人) 8、german(德国人) 9、nice(美好的)

　　10、meet(遇见) 11、japanese(日本人) 12、korean(韩国人)

　　13、chinese(中国人) 14、too(也) 15、make(产品的牌号)

　　四、

　　1、i(我) 2、name(名字) 3、what(什么) 4、nationality(国籍)

　　5、job(工作) 6、keyboard(电脑键盘) 7、operator(操作人员)

　　8、engineer(工程师) 9、policeman(警察) 10、policewoman(女警)

　　11、taxi driver(出租汽车司机) 12、air hostess(空中小姐)

　　13、postman(邮递员) 14、nurse(护士) 15、mechanic(机械师)

　　16、hairdresser(理发师) 17、housewife(家庭妇女) 18、milkman(送牛奶的人)

　　五、(9-10)

　　1、hello(喂) 2、hi(喂、嗨) 3、how(怎样) 4、today(今天) 5、well(身体好)

　　6、fine(美好的) 7、thanks(谢谢) 8、goodbye(再见) 9、see(见) 10、fat(胖的)

　　11、woman(女人) 12、thin(瘦的) 13、tall(高的) 14、short(矮的)

　　15、dirty(脏的) 16、clean(干净的) 17、hot(热的) 18、cold(冷的)

　　19、old(老的) 20、young(年轻的) 21、busy(忙的) 22、lazy(懒的)

　　六、(11-12)

　　1、whose(谁的) 2、blue(蓝色的) 3、perhaps(大概) 4、white(白色的)

　　5、catch(抓住) 6、father(父亲) 7、mother(母亲) 8、blouse(女衬衫)

　　9、sister(姐妹) 10、tie(领带) 11、brother(兄弟) 12、his/her(他/她的)

　　七、(13-14)

　　1、colour(颜色) 2、green(绿色) 3、come(来) 4、upstairs(楼上)

　　5、smart(时髦的、也代表聪明) 6、hat(帽子) 7、same(相同的)

　　8、lovely(可爱的、秀丽的) 9、case(箱子) 10、carpet(地毯) 11、dog(狗)

　　12、grey(灰色) 13、brown(棕色) 14、red(红色) 15、yellow(黄) 16、orange(橙色)

　　八、(15-16)

　　1、customs(海关) 2、officer(官员) 3、girl(女孩) 4、friend(朋友)

　　5、passport(护照)(pass/通过、port/港口) 6、tourist(旅行者) 7、these(这些this复数)

　　九、(17-18)

　　1、employee(雇员) 2、hard-working(勤奋的) 3、sales reps(推销员)(sales/销售)

　　4、man(男人) 5、office(办公室) 6、assistant(助手)

　　十、(19-20)

　　1、matter(事情) 2、children(孩子)(child的复数) 3、tired(累、疲乏)

　　4、boy(男孩) 5、thirsty(渴) 6、sit down(坐下) 7、right(可以)

　　8、ice cream(冰淇淋) 9、big(大的) 10、small(小的) 11、open(开着的)

　　12、shut(关着的) 13、light(轻的) 14、heavy(重的) 15、long(长的)

　　16、shoe(鞋子) 17、grandfather/mother(祖父/母)

	十一、(21-22)

　　1、give(给) 2、one(一个) 3、which(哪一个) 4、empty(空的) 5、full(满的)

　　6、large(大的) 7、little(小的) 8、sharp(锋利的) 9、small(小的)

　　10、big(大的) 11、blunt(钝的) 12、box(盒子) 13、glass(杯子)

　　14、cup(茶杯) 15、bottle(瓶子) 16、tin(罐头) 17、knife(刀子)

　　18、fork(叉子) 19、spoon(勺子)

　　十二、(23-24)

　　1、on(在.....之上) 2、shelf(架子、搁板) 3、desk(课桌) 4、table(桌子)

　　5、plate(盘子) 6、cupboard(食厨) 7、cigarette(香烟) 8、television(电视机)

　　9、floor(地板) 10、dressing(梳妆台) 11、magazine(杂志) 12、bed(床)

　　13、newspaper(报纸) 14、stereo(立体声音响)

　　十三、(25-26)

　　1、mrs(夫人) 2、kitchen(厨房) 3、refrigerator(电冰箱) 4、right(右边)

　　5、electric(带电的、可通电的) 6、left(左边) 7、cooker(炉子)

　　8、middle(中间) 9、of(属于.....的) 10、room(房间) 11、cup(杯子)

　　12、where(在哪里) 13、in(在.....里)

　　十四、(27-28)

　　1、living room(客厅) 2、near(靠近) 3、window(窗户) 4、armchair(扶手椅)

　　5、door(门) 6、picture(图画) 7、wall(墙) 8、trousers(长裤)

　　十五、(29-30)

　　1、shut(关门) 2、bedroom(卧室) 3、untidy(乱，不整齐) 4、must(必须，应该)

　　5、open(打开) 6、air(使.....通风，换换空气) 7、put(放置) 8、clothes(衣服)

　　9、wardrobe(大衣柜) 10、dust(掸掉灰尘) 11、sweep(扫) 12、empty(倒空)

　　13、read(读) 14、sharpen(削尖) 15、put on(穿上) 16、take off(脱掉)

　　17、turn on(开(电灯)) 18、turn off(关(电灯))

　　十六、(31-32)

　　1、garden(花园) 2、under(在...之下) 3、tree(树) 4、climb(爬、攀登)

　　5、who(谁) 6、run(跑) 7、grass(草、草地) 8、after(在....之后)

　　9、across(横过、穿过) 10、cat(猫) 11、type(打字) 12、letter(信)

　　13、basket(篮子) 14、eat(吃) 15、bone(骨头) 16、clean(清洗)

　　17、tooth(牙齿) 18、cook(做(饭)) 19、milk(牛奶) 20、meal(饭)

　　21、drink(喝) 22、tap((水)龙头)

　　十七、(33-34)

　　1、day(日子) 2、cloud(云) 3、sky(天空) 4、sun(太阳) 5、shine(照耀)

　　6、with(和.....在一起) 7、family(家庭) 8、walk(走路、步行) 9、over(跨越、在...之上)

　　10、bridge(桥) 11、boat(船) 12、river(河) 13、ship(轮船) 14、fly(飞)

　　15、aeroplane(飞机) 16、sleep(睡觉) 17、shave(刮脸) 18、cry(哭、喊)

　　19、wash(洗) 20、wait(等) 21、jump(跳)

　　十八、(35-36)

　　1、photograph(照片) 2、village(村庄) 3、valley(山谷) 4、between(在...之间)

　　5、hill(小山) 6、another(另一个) 7、wife(妻子) 8、along(沿着)

　　9、bank(河岸) 10、water(水) 11、swim(游泳) 12、building(大楼、建筑物)

　　13、park(公园) 14、into(进入) 15、beside(在...旁) 16、off(离开)

　　十九、(37-38)

　　1、work(工作) 2、hard(努力地) 3、make(做) 4、bookcase(书橱、书架)

　　5、hammer(锤子) 6、paint(上漆、涂) 7、pink(粉红色) 8、favourite(最喜欢的)

　　9、homework(作业) 10、listen(听) 11、dish(盘子、碟子)

　　二十、(39-40)

　　1、front(前面) 2、in front of(在.....之前) 3、careful(小心的、仔细的)

　　4、vase(花瓶) 5、drop(掉下) 6、flower(花) 7、show(给.....看)

　　8、send(送给) 9、take(带给)

	二十一、(41-42)

　　1、cheese(乳酪、干酪) 2、bread(面包) 3、soap(肥皂) 4、chocolate(巧克力)

　　5、sugar(糖) 6、coffee(咖啡) 7、tea(茶) 8、tobacoo(烟草、烟丝)

　　9、bird(鸟) 10、any(一些)(否定句) 11、some(一些)(肯定句)

　　二十二、(43-44)

　　1、of course(当然) 2、kettle(水壶) 3、behind(在...后面) 4、teapot(茶壶)

　　5、now(现在、此刻) 6、find(找到) 7、boil(沸腾、开)

　　二十三、(45-46)

　　1、can(能够) 2、boss(老板) 3、minute(分) 4、ask(请求、要求)

　　5、handwriting(书写)(hand/手、writing/写) 6、terrible(糟糕的、可怕的)

　　7、lift(拿起、搬起、举起) 8、cake(饼、蛋糕) 9、biscuit(饼干)

　　二十四、(47-48)

　　1、like(喜欢、想要) 2、want(想) 3、fresh(新鲜) 4、egg(鸡蛋)

　　5、butter(黄油) 6、pure(纯净的) 7、honey(蜂蜜) 8、ripe(成熟的)

　　9、banana(香蕉) 10、jam(果酱) 11、sweet(甜的) 12、orange(橙)

　　13、scotch whisky(苏格兰威士忌) 14、choice(上等的、精选的)

　　15、apple(苹果) 16、wine(酒、果酒) 17、beer(啤酒) 18、blackboard(黑板)

　　二十五、(49-50)

　　1、butcher(卖肉的) 2、meat((食用)肉) 3、beef(牛肉) 4、lamb(羔羊肉)

　　5、husband(丈夫) 6、steak(牛排) 7、mince(肉馅) 8、chicken(鸡)

　　9、tell(告诉) 10、truth(实情) 11、either(也) 12、tomato(西红柿)

　　13、potato(土豆) 14、cabbage(卷心菜) 15、lettuce(莴苣) 16、pea(豌豆)

　　17、bean(豆角) 18、pear(梨) 19、grape(葡萄) 20、peach(桃)

　　二十六、(51-52)

　　1、climate(气候) 2、country(国家) 3、pleasant(宜人的) 4、weather(天气)

　　5、spring(春季) 6、windy(有风的) 7、warm(温暖的) 8、rain(下雨)

　　9、sometimes(有时) 10、summer(夏天) 11、autumn(秋天) 12、winter(冬天)

　　13、snow(下雪) 14、january(1月) 15、february(2月) 16、march(3月)

　　17、april(4月) 18、may(5月) 19、june(6月) 20、july(7月) 21、august(8月)

　　22、september(9月) 23、october(10月) 24、november(11月) 25、december(12月)

　　二十七、(53-54)

　　1、mild(温暖的、温和的) 2、always(总是) 3、north(北方) 4、east(东方)

　　5、wet(潮湿的) 6、west(西方) 7、south(南方) 8、season(季节) 9、best(最)

　　10、night(夜晚) 11、rise(升起) 12、early(早) 13、set((太阳)落下去)

　　14、late(晚、迟) 15、interesting(有趣的、有意思的) 16、subject(话题) 17、conversation(谈话)

　　二十八、(55-56)

　　1、live(住、生活) 2、stay(呆在、停留) 3、home(家) 4、housework(家务)

　　5、lunch(午饭) 6、afternoon(下午) 5、usually(通常) 6、together(一起)

　　7、evening(晚上) 8、arrive(到达) 9、night(夜间)

　　二十九、(57-58)

　　1、o'clock(点钟) 2、shop(商店) 3、moment(片刻、瞬间)

　　三十、(59-60)

　　1、envelope(信封) 2、writing paper(信纸) 3、shop assistant(售货员)

　　4、size(尺寸、尺码、大小) 5、pad(信笺薄) 6、glue(胶水) 7、chalk(粉笔)

　　8、change(零钱、找给的钱)

	三十一、(61-62)

　　1、feel(感觉) 2、look(看) 3、must(必须) 4、call(叫、请) 5、doctor(医生)

　　6、telephone(电话) 7、remember(记得、记住) 8、mouth(嘴) 9、tongue(舌头)

　　10、bad(坏的、严重的) 11、cold(感冒) 12、news(消息) 13、headache(头痛)

　　14、aspirin(阿司匹林) 15、earache(耳痛) 16、toothache(牙痛) 17、dentist(牙医) 18、stomach ache(胃痛) 19、medicine(药) 20、temperature(温度) 21、flu(流行性感冒) 22、measles(麻疹) 23、mumps(鉰腺炎)

　　三十二、(63-64)

　　1、better(形容词well的比较级) 2、certainly(当然) 3、get up(起床)

　　4、yet(还、仍) 5、rich(油腻的) 6、food(食物) 7、remain(保持、继续)

　　8、play(玩) 9、match(火柴) 10、talk(谈话) 11、library(图书馆)

　　12、drive(开车) 13、so(如此地) 14、quickly(快地) 15、lean out of(身体深处)

　　16、break(打破) 17、noise(喧闹声)

　　三十三、(65-66)

　　1、key(钥匙) 2、baby(婴儿) 3、hear(听见) 4、enjoy(玩得快活)

　　5、yourself(你自己) 6、ourselves(我们自己) 7、myself(我自己)

　　8、themselves(他们自己) 9、himself(他自己) 10、herself(她自己)

　　三十四、(67-68)

　　1、greengrocer(蔬菜水果零售商) 2、absent(缺席的) 3、monday(星期一)

　　4、tuesday(星期二) 5、wednesday(星期三) 6、thursday(星期四)

　　7、firday(星期五) 8、saturday(星期六) 9、sunday(星期日)

　　10、keep(身体健康) 11、spend(度过) 12、weekend(周末(week/周末、end/末端))

　　13、country(乡村、国家) 14、lucky(幸运的) 15、church(教堂)

　　16、dairy(乳品店) 17、baker(面包师父) 18、grocer(食品杂货商)

　　三十五、(69-70)

　　1、year(年) 2、race(比赛) 3、town(城镇) 4、crowd(人群)

　　5、stand(站立) 6、exciting(使人激动的) 7、just(正好、恰好)

　　8、finish(结尾、结束) 9、winner(获胜者) 10、behind(在...之后)

　　11、way(路途) 12、stationer(文具商)

　　三十六、(71-72)

　　1、awful(让人讨厌的、坏的) 2、telephone(打电话、电话)

　　3、time(次(数)) 4、answer(接(电话)) 5、last(最后的，前一次的)

　　6、phone(电话) 7、again(又一次的) 8、say(说)

　　三十七、(73-74)

　　1、week(周) 2、suddenly(突然地) 3、bus stop(公共汽车车站) 4、smile(微笑) 5、pleasantly(愉快地) 6、understand(懂、明白) 7、speak(讲、说)

　　8、pocket(衣袋) 9、phrasebook(短语手册、常用语手册) 10、phrase(短语) 11、slowly(缓慢地) 12、hurriedly(匆忙地) 13、cut(割、切) 14、thirstily(口渴地) 15、go(走) 16、greet(问候、打招呼)

三十八、(75-76)

　　1、ago(以前) 2、buy(买) 3、pair(双、对) 4、fashion(流行) 5、uncomfortable(不舒服的) 6、wear(穿)

三十九、(77-78)

　　1、appointment(预约、约会) 2、urgent(紧急的、急迫的) 3、till(直到...为止)

四十、(79-80)

　　1、shopping(购物) 2、list(单子) 3、vegetable(蔬菜) 4、need(需要) 5、hope(希望) 6、thing(事情) 7、money(钱) 8、groceries(食品杂货) 9、fruit(水果) 10、stationery(文具) 11、newsagent(报刊零售人) 12、chemist(药剂师、化学家)

四十一、(81-82)

　　1、bath(洗澡) 2、nearly(几乎、将近) 3、ready(准备好的、完好的) 4、dinner(正餐、晚餐) 5、restaurant(饭馆、餐馆) 6、roast(烤的) 7、breakfast(早饭) 8、haircut(理发) 9、party(聚会) 10、holiday(假日)

四十二、(83-84)

　　1、mess(杂乱、凌乱) 2、pack(包装、打包、装箱)

　　3、suitcase(手提箱) 4、leave(离开) 5、already(已经) 

四十三、(85-86)

　　1、paris(巴黎) 2、cinema(电影院) 3、film(电影) 4、beautiful(漂亮的) 5、city(城市) 6、never(从来没有) 7、ever(在任何时候)

四十四、(87-88)

　　1、attendant(接待员) 2、bring(带来、送来) 3、garage(车库、汽车修理厂) 4、crash(碰撞) 5、lamp(灯杆) 6、repair(修理) 7、try(努力、设法)

四十五、(89-90)

　　1、believe(相信、认为) 2、may(可以) 3、how long(多长) 4、since(自从) 5、why(为什么) 6、sell(卖、出售)(sold) 7、because(因为) 8、retire(退休) 9、cost(花费) 10、pound(英镑) 11、worth(值...钱) 12、penny(便士)

四十六、(91-92)

　　1、still(还、仍旧) 2、move(搬家) 3、miss(想念、思念) 4、neighbour(邻居) 5、person(人) 6、people(人们) 7、poor(可怜的)

四十七、(93-94)

　　1、pilot(飞行员) 2、return(返回) 3、new york(纽约) 4、tokyo(东京) 5、madrid(马德里) 6、fly(飞行)(flew/flown)

四十八、(95-96)

　　1、return(往返) 2、train(火车) 3、platform(站台) 4、plenty(大量) 5、bar(酒吧) 6、station(车站、火车站) 7、porter(售票员) 8、catch(赶上)(caught) 9、miss(错过)

四十九、(97-98)
	1、leave(遗留) 2、describe(描述) 3、zip(拉链) 4、label(标签) 5、handle(提手、把手) 6、address(地址) 7、pence(penny的复数形式) 8、belong(属于)

五十、(99-100)
　　1、ow(哎哟) 2、slip(滑倒) 3、fall(落下、跌倒) 4、downstairs(下楼) 5、hurt(伤、疼痛) 6、back(背) 7、stand up(起立、站起来) 8、help(帮助) 9、at once(立即) 10、sure(一定的、确信的) 11、x-ray(x光透视) 12、licence(执照)

五十一、(101-102)
　　1、card(明信片) 2、youth(青年) 3、hostel(招待所、旅馆) 4、association(协会) 5、soon(不久) 6、write(写)(wrote/written)

五十二、(103-104)

　　1、exam(考试) 2、pass(及格、通过) 3、mathematics(数学(maths缩写)) 4、question(问题) 5、easy(容易的) 6、enough(足够的) 7、paper(考卷) 8、fail(未及格、失败) 9、answer(回答) 10、mark(分数) 11、rest(其它的东西) 12、difficult(困难的) 13、hate(讨厌) 14、low(低) 15、cheer(振作) 16、guy(家伙、人) 17、top(上方、顶部) 18、clever(聪明的) 19、stupid(笨的) 20、cheap(便宜的) 21、expensive(贵的) 22、fresh(新鲜的) 23、stale(变馊的) 24、loud(大声的) 25、high(高的) 26、hard(硬的) 27、soft(软的) 28、sour(酸的)

五十三、(105-106)
　　1、spell(拼写)(spelt) 2、intelligent(聪明的、有智慧的) 3、mistake(错误) 4、present(礼物) 5、dictionary(词典) 6、carry(携带) 7、correct(改正、纠正) 8、keep(保存、保留)

五十四、(107-108)

　　1、madam(夫人、女士) 2、smart(漂亮的) 3、as well(同样) 4、suit(适于) 5、pretty(漂亮的)
五十五、(109-110)

　　1、idea(主意) 2、a little(少许) 3、teaspoonful(一满茶匙) 4、less(较少的、little比较级) 5、a few(几个) 6、pity(遗憾) 7、instead(代替) 8、advice(建议、忠告) 9、most(最多的)(many,much的最高级) 10、least(最小的、最少的)(little的最高级) 11、best(最好的)

　　(good的最高级) 12、worse(更坏的)(bad的比较级) 13、worst(最坏的)(bad的最高级)

五十六、(111-112)

　　1、model(型号、式样) 2、afford(付得起(钱)) 3、deposit(预付定金) 4、instalment(分期付款) 5、price(价格) 6、millionaire(百万富翁)

五十七、(113-114)

　　1、conductor(售票员) 2、fare(车费、车票) 3、change(兑换(钱)) 4、note(纸币) 5、passenger(乘客) 6、none(没有任何东西) 7、neither(也不) 8、get off(下车) 9、tramp(流浪汉) 10、except(除...外)
五十八、(115-116)

　　1、anyone(任何人) 2、knock(敲、打) 3、everything(一切事情) 4、quiet(安静的) 5、impossible(不可能的) 6、invite(邀请) 7、anything(任何东西) 8、nothing(什么也没有) 9、lemonade(柠檬水) 10、joke(开玩笑) 11、asleep(睡觉) 12、glasses(眼镜)
五十九、(117-118)

　　1、dining room(饭厅) 2、coin(硬币) 3、mouth(嘴) 4、swallow(吞下) 5、later(后来) 6、toilet(厕所)
六十、(119-120)
　　1、story(故事) 2、happen(发生) 3、thief(贼)
　　4、enter(进入) 5、dark(黑暗的) 6、torch(手电筒) 7、voice(声音) 8、parrot(鹦鹉)
六十一、(121-122)
　　1、customer(顾客) 2、forget(忘记) 3、manager(经理) 4、serve(照应、服务、接待) 5、counter(柜台) 6、recognize(认出) 7、road(路)
六十二、(123-124)
　　1、during(在...期间) 2、trip(旅行) 3、travel(旅行) 4、offer(提供) 5、job(工作) 6、guess(猜) 7、grow(长、让...生长)(grew/grown) 8、beard(胡子、落腮胡子) 9、kitten(小猫)
六十三、(125-126)
　　1、water(浇水) 2、terribly(非常) 3、dry(干燥的、干的) 4、nuisance(讨厌的东西或人) 5、mean(意味着)(meant) 6、surprise(惊奇、意外的事)
　　7、immediately(立即地)
六十四、(127-128)
　　1、famous(著名的) 2、actress(女演员) 3、at least(至少) 4、actor(男演员) 5、read(通过阅读得知)
六十五、(129-130)
　　1、wave(招手) 2、track(跑道) 3、mile(英里) 4、overtake(从后面超越、超车)(overtook/overtaken) 5、speed limit(限速) 6、dream(做梦、思想不集中) 7、sign(标记、牌子) 8、driving licence(驾驶执照) 9、charge(罚款) 10、darling(亲爱的)
六十六、(131-132)
　　1、egypt(埃及) 2、abroad(国外) 3、worry(担忧)
六十七、(133-134)
　　1、reporter(记者) 2、sensational(爆炸性的、耸人听闻的) 3、mink coat(貂皮大衣)
六十八、(135-136)
　　1、future(未来的) 2、get married(结婚) 3、hotel(饭店) 4、latest(最新的) 5、introduce(介绍)
六十九、(137-138)
　　1、football(足球) 2、pool(赌注) 3、win(赢)(won) 4、world(世界) 5、poor(贫穷的) 6、depend(依靠)
七十、(139-140)
　　1、extra(额外的) 2、overseas(海外的、国外的) 3、engineering(工程) 4、company(公司) 5、line(线路) 
七十一、(141-142)
　　1、excited(兴奋的) 2、get on(登上) 3、middle-aged(中年的) 4、opposite(在...对面) 5、curiously(好奇的) 6、funny(可笑的、滑稽的) 7、powder(香粉) 8、compact(戴镜的化妆盒) 9、kindly(和蔼的) 10、ugly(丑陋的) 11、amused(有趣的) 12、embarrassed(尴尬的、窘迫的) 13、worried(担心、担忧) 14、regularly(经常地、定期地)七十二、(143-144)
　　1、surround(包围) 2、wood(树林) 3、beauty spot(风景点) 4、hundred(百) 5、city(城市) 6、through(穿过) 7、visitor(参观者、游客、来访者) 8、tidy(整齐的) 9、litter(杂乱的东西) 10、litter basket(废物筐) 11、place(放) 12、throw(扔、抛)(threw/thrown) 13、rubbish(垃圾) 14、count(数、点) 15、cover(覆盖) 16、piece(碎片) 17、tyre(轮胎) 18、rusty(生锈的) 19、among(在...之间) 20、prosecute(依法处置)