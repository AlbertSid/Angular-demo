package main

import (
    "fmt"
    "math"
    "os"
    "time"
    "io"
    "strings"
    "log"
    "net/http"
    "image"
)
/*
方法
Go 没有类。然而，仍然可以在结构体类型上定义方法。

方法接收者 出现在 func 关键字和方法名之间的参数中。
*/
type Vertex struct {
    X, Y float64
}

func (v *Vertex) Abs() float64 {
    return math.Sqrt(v.X*v.X + v.Y*v.Y)
}

/*
方法（续）
你可以对包中的 任意 类型定义任意方法，而不仅仅是针对结构体。

但是，不能对来自其他包的类型或基础类型定义方法。
*/
type MyFloat float64

func (f MyFloat) Abs() float64 {
    if f < 0 {
        return float64(-f)
    }
    return float64(f)
}

/*
接收者为指针的方法
方法可以与命名类型或命名类型的指针关联。

刚刚看到的两个 Abs 方法。一个是在 *Vertex 指针类型上，而另一个在 MyFloat 值类型上。 有两个原因需要使用指针接收者。首先避免在每个方法调用中拷贝值（如果值类型是大的结构体的话会更有效率）。其次，方法可以修改接收者指向的值。

尝试修改 Abs 的定义，同时 Scale 方法使用 Vertex 代替 *Vertex 作为接收者。

当 v 是 Vertex 的时候 Scale 方法没有任何作用。`Scale` 修改 `v`。当 v 是一个值（非指针），方法看到的是 Vertex 的副本，并且无法修改原始值。

Abs 的工作方式是一样的。只不过，仅仅读取 `v`。所以读取的是原始值（通过指针）还是那个值的副本并没有关系。
*/
type Vertex2 struct {
    X, Y float64
}

func (v *Vertex2) Scale(f float64) {
    v.X = v.X * f
    v.Y = v.Y * f
}

func (v *Vertex2) Abs() float64 {
    return math.Sqrt(v.X*v.X + v.Y*v.Y)
}


/*
接口
接口类型是由一组方法定义的集合。

接口类型的值可以存放实现这些方法的任何值。

*/



type MyFloat3 float64

func (f MyFloat3) Abs() float64 {
    if f < 0 {
        return float64(-f)
    }
    return float64(f)
}

type Vertex3 struct {
    X, Y float64
}

func (v *Vertex3) Abs() float64 {
    return math.Sqrt(v.X*v.X + v.Y*v.Y)
}

type Abser interface {
    Abs() float64
}


type Reader interface {
    Read(b []byte) (n int, err error)
}

type Writer interface {
    Write(b []byte) (n int, err error)
}

type ReadWriter interface {
    Reader
    Writer
}

func main() {
    //方法
    vm := &Vertex{3, 4}
    fmt.Println(vm, vm.Abs())

    //方法（续）
    fm := MyFloat(-math.Sqrt2)
    fmt.Println(fm, fm.Abs())

    // 接收者为指针的方法
    // 方法可以与命名类型或命名类型的指针关联。
    v2 := &Vertex2{3, 4}
    v2.Scale(5)
    fmt.Println(v2, v2.Abs())


    // 接口
    // 接口类型是由一组方法定义的集合。

    // 接口类型的值可以存放实现这些方法的任何值。
    var a Abser
    a = MyFloat3(-math.Sqrt2)  // a MyFloat 实现了 Abser
    fmt.Println(a,a.Abs()) //同名Abs
    /* 
    v := Vertex3{3, 4}
    a = &v 
    */
    a = &Vertex3{3, 4} // a *Vertex 实现了 Abser
    fmt.Println(a,a.Abs())//同名Abs


    /*
隐式接口
类型通过实现那些方法来实现接口。 没有显式声明的必要；所以也就没有关键字“implements“。

隐式接口解藕了实现接口的包和定义接口的包：互不依赖。

因此，也就无需在每一个实现上增加新的接口名称，这样同时也鼓励了明确的接口定义。

包 io 定义了 Reader 和 `Writer`；其实不一定要这么做。
    */

    var w Writer

    // os.Stdout 实现了 Writer
    w = os.Stdout

    fmt.Fprintf(w, "hello, writer\n")



    /*
Stringers
一个普遍存在的接口是 fmt 包中定义的 Stringer。

type Stringer struct {
    String() string
}
Stringer 是一个可以用字符串描述自己的类型。`fmt`包 （还有许多其他包）使用这个来进行输出。
    */
    a2 := Person{"Arthur Dent", 42}
    z2 := Person{"Zaphod Beeblebrox", 9001}
    fmt.Println(a2, z2)

    // test    
    addrs := map[string]IPAddr{
        "loopback":  {127, 0, 0, 1},
        "googleDNS": {8, 8, 8, 8},
    }
    for n, a := range addrs {
        fmt.Printf("%v: %v\n", n, a)
    }


    // 错误
    if err := run(); err != nil {
        fmt.Println(err)
    }
    fmt.Println(Sqrt(2))
    fmt.Println(Sqrt(-2))

    /*
Readers
io 包指定了 io.Reader 接口， 它表示从数据流结尾读取。

Go 标准库包含了这个接口的许多实现， 包括文件、网络连接、压缩、加密等等。

io.Reader 接口有一个 Read 方法：

func (T) Read(b []byte) (n int, err error)
Read 用数据填充指定的字节 slice，并且返回填充的字节数和错误信息。 在遇到数据流结尾时，返回 io.EOF 错误。

例子代码创建了一个 strings.Reader。 并且以每次 8 字节的速度读取它的输出。

    */
    r := strings.NewReader("Hello, Reader!")

    b := make([]byte, 8)
    for {
        n, err2 := r.Read(b)
        fmt.Printf("n = %v err = %v b = %v\n", n, err2, b)
        fmt.Printf("b[:n] = %q\n", b[:n])
        if err2 == io.EOF {
            break
        }
    }

    /*
    练习：Reader
    实现一个 Reader 类型，它不断生成 ASCII 字符 'A' 的流。
    
    type rot13Reader struct {
        r io.Reader
    }
    s := strings.NewReader("Lbh penpxrq gur pbqr!")
    r := rot13Reader{s}
    io.Copy(os.Stdout, &r)
    */
/*
Web 服务器
包 http 通过任何实现了 http.Handler 的值来响应 HTTP 请求：

package http

type Handler interface {
    ServeHTTP(w ResponseWriter, r *Request)
}
在这个例子中，类型 Hello 实现了 `http.Handler`。

访问 http://localhost:4000/ 会看到来自程序的问候。
*/


    var h Hello
    err := http.ListenAndServe("localhost:4000", h)
    if err != nil {
        log.Fatal(err)
    }


/*
练习：HTTP 处理
实现下面的类型，并在其上定义 ServeHTTP 方法。在 web 服务器中注册它们来处理指定的路径。

type String string

type Struct struct {
    Greeting string
    Punct    string
    Who      string
}
例如，可以使用如下方式注册处理方法：

http.Handle("/string", String("I'm a frayed knot."))
http.Handle("/struct", &Struct{"Hello", ":", "Gophers!"})
*/   
    // log.Fatal(http.ListenAndServe("localhost:4000", nil))


/*

图片
Package image 定义了 Image 接口：

package image

type Image interface {
    ColorModel() color.Model
    Bounds() Rectangle
    At(x, y int) color.Color
}
*注意*：`Bounds` 方法的 Rectangle 返回值实际上是一个 image.Rectangle， 其定义在 image 包中。

（参阅文档了解全部信息。）

color.Color 和 color.Model 也是接口，但是通常因为直接使用预定义的实现 image.RGBA 和 image.RGBAModel 而被忽视了。这些接口和类型由image/color 包定义。
*/

    m := image.NewRGBA(image.Rect(0, 0, 100, 100))
    fmt.Println("m", m.Bounds())
    fmt.Println(m.At(0, 0).RGBA())



}


type Person struct {
    Name string
    Age  int
}

func (p Person) String() string {
    return fmt.Sprintf("%v (%v years)", p.Name, p.Age)
}

// 让 IPAddr 类型实现 fmt.Stringer 以便用点分格式输出地址。
// 例如，`IPAddr{1,`2,`3,`4}` 应当输出 `"1.2.3.4"`。
type IPAddr [4]byte


/*
错误
Go 程序使用 error 值来表示错误状态。

与 fmt.Stringer 类似，`error` 类型是一个内建接口：

type error interface {
    Error() string
}
（与 fmt.Stringer 类似，`fmt` 包在输出时也会试图匹配 `error`。）

通常函数会返回一个 error 值，调用的它的代码应当判断这个错误是否等于 `nil`， 来进行错误处理。

i, err := strconv.Atoi("42")
if err != nil {
    fmt.Printf("couldn't convert number: %v\n", err)
}
fmt.Println("Converted integer:", i)
error 为 nil 时表示成功；非 nil 的 error 表示错误。
*/
type MyError struct {
    When time.Time
    What string
}

func (e *MyError) Error() string {
    return fmt.Sprintf("at %v, %s",
        e.When, e.What)
}

func run() error {
    return &MyError{
        time.Now(),
        "it didn't work",
    }
}
/*
练习：错误
从之前的练习中复制 Sqrt 函数，并修改使其返回 error 值。

Sqrt 接收到一个负数时，应当返回一个非 nil 的错误值。复数同样也不被支持。

创建一个新类型

type ErrNegativeSqrt float64
为其实现

func (e ErrNegativeSqrt) Error() string
使其成为一个 `error`， 该方法就可以让 ErrNegativeSqrt(-2).Error() 返回 `"cannot Sqrt negative number: -2"`。

注意： 在 Error 方法内调用 fmt.Sprint(e) 将会让程序陷入死循环。可以通过先转换 e 来避免这个问题：`fmt.Sprint(float64(e))`。请思考这是为什么呢？

修改 Sqrt 函数，使其接受一个负数时，返回 ErrNegativeSqrt 值。
*/
func Sqrt(x float64) (float64, error) {
    return 0, nil
}

type Hello struct{}

func (h Hello) ServeHTTP(
    w http.ResponseWriter,
    r *http.Request) {
    fmt.Fprint(w, "Hello!")
}

