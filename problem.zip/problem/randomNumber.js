function rnd(start, end) {
    return Math.floor(Math.random() * (end - start) + start);
}

function getRandom(n, m) {
    //省略特殊情形下的处理过程，比如n>m，或者n、m之一无法转化为有效数字；
    return Math.round(Math.random() * (m - n) + n);
}