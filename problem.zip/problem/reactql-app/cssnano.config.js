/* eslint-disable import/no-extraneous-dependencies */
const defaultPreset = require('cssnano-preset-default');

module.exports = defaultPreset({
  normalizeUrl: false,
});
