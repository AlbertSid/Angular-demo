    //1
    var pasteEvent = new ClipboardEvent('paste');
    pasteEvent.clipboardData.items.add('My string', 'text/plain');
    document.dispatchEvent(pasteEvent);

    //2
    //覆盖正在复制到剪贴板的内容。
    document.addEventListener('copy', function(e) {
        // e.clipboardData最初是空的,但我们可以将它设置为
        //我们想要复制到剪贴板上的数据。
        e.clipboardData.setData('text/plain', 'Hello,world！');
        e.clipboardData.setData('text/html', '<b> Hello,world！</ b>');

        //这是防止当前文档选择所必需的
        //正在写入剪贴板。
        e.preventDefault();
    });



    //3
    //覆盖拷贝到剪贴板的内容
    document.addEventListener('cut', function(e) {
        // e.clipboardData最初是空的,但我们可以将它设置为
        //我们想要复制到剪贴板上的数据作为剪辑的一部分。
        //将要复制的数据写入剪贴板。
        e.clipboardData.setData('text/plain', 'Hello,world！');
        e.clipboardData.setData('text/html', '<b> Hello,world！</ b>');

        //由于我们将取消剪切操作,我们需要手动
        //更新文档以删除当前选定的文本。
        deleteCurrentDocumentSelection();

        //这是防止文档选择的必要条件
        //写入剪贴板。
        e.preventDefault();
    });

    function deleteCurrentDocumentSelection() {

    }

    //4
    //覆盖正在粘贴到剪贴板上的内容。
    document.addEventListener('paste', function(e) {
        // e.clipboardData包含即将被粘贴的数据。
        if (e.clipboardData.types.indexOf('text/html') > -1) {
            var oldData = e.clipboardData.getData('text/html');
            var newData = '<b>哈哈！</ b>' + oldData;

            //由于我们取消了粘贴操作,我们需要手动
            //将数据粘贴到文档中。
            pasteClipboardData(newData);

            //这是防止默认粘贴操作所必需的。
            e.preventDefault();
        }
    });

    function pasteClipboardData() {

    }

    //5
    navigator.clipboard.read().then(function(data) {
        for (var i = 0; i < data.items.length; i++) {
            if (data.items[i].type == "text/plain") {
                console.log("Your string: ", data.items[i].getAs("text/plain"));
            } else {
                console.error("No text/plain data on clipboard.");
            }
        }
    });
    //6
    navigator.clipboard.read().then(function(data) {
        console.log("Your string: ", data);
    });
    //7
    var data = new DataTransfer();
    data.items.add("text/plain", "Howdy, partner!");
    navigator.clipboard.write(data).then(function() {
        console.log("Copied to clipboard successfully!");
    }, function() {
        console.error("Unable to write to clipboard. :-(");
    });


    //8
    navigator.clipboard.writeText("Howdy, partner!").then(function() {
        console.log("Copied to clipboard successfully!");
    }, function() {
        console.error("Unable to write to clipboard.: -(");
    });