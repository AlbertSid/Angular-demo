
# numpy
[python-numpy-tutorial](http://cs231n.github.io/python-numpy-tutorial/)













