# -*- coding: utf-8 -*-
import os
import oss2

def upload(local_filename, remote_filename):
    access_key_id = os.getenv('OSS_TEST_ACCESS_KEY_ID', 'LTAIQ2HYKmn2QMIa')
    access_key_secret = os.getenv('OSS_TEST_ACCESS_KEY_SECRET', 'u0bTRsMQnGVdq8zs3AamjOOoaV4Fen')
    bucket_name = os.getenv('OSS_TEST_BUCKET', 'wrd-app')
    endpoint = os.getenv('OSS_TEST_ENDPOINT','oss-cn-hongkong.aliyuncs.com')
    auth = oss2.Auth(access_key_id, access_key_secret)
    bucket = oss2.Bucket(auth, endpoint, bucket_name)
    try:
        bucket.put_object_from_file(remote_filename, local_filename)
    except oss2.exceptions.NoSuchKey as e:
        print('status={0}, request_id={1}'.format(e.status, e.request_id))

# upload('test/android_kashbet_develop_2.0.1.4.5.118.apk', 'android_kashbet_develop_2.0.1.4.5.118.apk')
upload('C:/Users/Tattoo.L/Downloads/test.txt','test.txt')




