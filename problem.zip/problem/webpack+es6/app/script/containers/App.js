import React from 'react'

const App = () => (
	<div>
		21342
	</div>
)

export default App