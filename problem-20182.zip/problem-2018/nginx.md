[nginx服务器安装及配置文件详解](https://segmentfault.com/a/1190000002797601)
[nginx和php-fpm基础环境的安装和配置](https://segmentfault.com/a/1190000003067656)
[Nginx 中文官方文档](https://wizardforcel.gitbooks.io/nginx-doc/content/Text/1.1_overview.html)
[Windows下Nginx+Tomcat整合的安装与配置](https://www.jianshu.com/p/9d31fea58330)
[Nginx - Windows下Nginx基本安装和配置](http://blog.csdn.net/jQuerys/article/details/47904785)
[windows下配置nginx+php环境](http://www.cnblogs.com/huayangmeng/archive/2011/06/15/2081337.html)
[window下nginx+apache配置](https://www.phpsong.com/272.html)

**[Nginx + phalcon](https://olddocs.phalconphp.com/en/3.0.0/reference/nginx.html)**
**[Nginx + phalcon](https://docs.phalconphp.com/en/3.1/webserver-setup)**

[phalcon中文网](http://phalcon.ipanta.com/)
[关于nginx配置 获取静态资源](https://segmentfault.com/q/1010000005687627)

```
nginx/conf/nginx.conf
server {
    listen 80;
    server_name a.xxx.com;
    index index.html index.shtml index.php;
    root /Users/xxx/WebstromProjects/myproject/server;
    location / {
       // server
    }
    location ~ /(javascript|css|images) {
        root /Users/xxx/WebstromProjects/myproject/web;
    }
}

server {
    listen 80;
    server_name a.xxx.com;
    index index.shtml index.html index.php;
    root /Users/xxx/WebstormProjects/myprojects/web/;
    location / {
        try_files $uri $uri/ /index.php$is_args$args;
    }
    location ~ \.php$ {
        root /Users/xxx/WebstromProjects/myprojects/server/;
        fastcgi_pass  127.0.0.1:9001;
        fastcgi_index index.php;
        include fastcgi.conf;
    }
}
  server {
         location ~ ^/(images|javascript|js|css|flash|media|static)/  {
           root        E:\svn\web;
           access_log  off;
           expires     30d;
         }
```
















