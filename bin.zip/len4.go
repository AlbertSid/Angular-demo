package main

import (
    "fmt"
    "time"
)


/*
goroutine
goroutine 是由 Go 运行时环境管理的轻量级线程。

go f(x, y, z)
开启一个新的 goroutine 执行

f(x, y, z)
f ， x ， y 和 z 是当前 goroutine 中定义的，但是在新的 goroutine 中运行 `f`。

goroutine 在相同的地址空间中运行，因此访问共享内存必须进行同步。sync 提供了这种可能，不过在 Go 中并不经常用到，因为有其他的办法。（在接下来的内容中会涉及到。）
*/
func say(s string) {
    for i := 0; i < 5; i++ {
        time.Sleep(100 * time.Millisecond)
        fmt.Println(s)
    }
}
/*

channel
channel 是有类型的管道，可以用 channel 操作符 <- 对其发送或者接收值。

ch <- v    // 将 v 送入 channel ch。
v := <-ch  // 从 ch 接收，并且赋值给 v。
（“箭头”就是数据流的方向。）

和 map 与 slice 一样，channel 使用前必须创建：

ch := make(chan int)
默认情况下，在另一端准备好之前，发送和接收都会阻塞。这使得 goroutine 可以在没有明确的锁或竞态变量的情况下进行同步。
*/
func sum(a []int, c chan int) {
    sum := 0
    for _, v := range a {
        sum += v
    }
    c <- sum // 将和送入 c
}

/*
缓冲 channel
channel 可以是 _带缓冲的_。为 make 提供第二个参数作为缓冲长度来初始化一个缓冲 channel：

ch := make(chan int, 100)
向缓冲 channel 发送数据的时候，只有在缓冲区满的时候才会阻塞。当缓冲区清空的时候接受阻塞。

修改例子使得缓冲区被填满，然后看看会发生什么。
*/



/*
range 和 close
发送者可以 close 一个 channel 来表示再没有值会被发送了。
接收者可以通过赋值语句的第二参数来测试 channel 是否被关闭：
当没有值可以接收并且 channel 已经被关闭，那么经过

v, ok := <-ch
之后 ok 会被设置为 `false`。

循环 `for i := range c` 会不断从 channel 接收值，直到它被关闭。

注意： 只有发送者才能关闭 channel，而不是接收者。向一个已经关闭的 channel 发送数据会引起 panic。 
还要注意： channel 与文件不同；通常情况下无需关闭它们。
只有在需要告诉接收者没有更多的数据的时候才有必要进行关闭，例如中断一个 `range`。
*/
func fibonacci(n int, c chan int) {
    x, y := 0, 1
    for i := 0; i < n; i++ {
        c <- x
        x, y = y, x+y
    }
    close(c)
}


/*
select
select 语句使得一个 goroutine 在多个通讯操作上等待。

select 会阻塞，直到条件分支中的某个可以继续执行，这时就会执行那个条件分支。当多个都准备好的时候，会随机选择一个。
*/
func fibonacci2(c, quit chan int) {
    x, y := 0, 1
    for {
        select {
        case c <- x:
            x, y = y, x+y
        case <-quit:
            fmt.Println("quit")
            return
        }
    }
}


func main() {
    //goroutine
    go say("world")
    say("hello") 


    //channel
    a := []int{7, 2, 8, -9, 4, 0}

    c := make(chan int)
    go sum(a[:len(a)/2], c)
    go sum(a[len(a)/2:], c)
    x, y := <-c, <-c // 从 c 中获取

    fmt.Println(x, y, x+y)

    // 缓冲 channel
    c2 := make(chan int, 2)
    c2 <- 1
    c2 <- 2
    fmt.Println(<-c2)
    fmt.Println(<-c2)

    fmt.Println("---------range 和 close-------------")
    //range 和 close
    c3 := make(chan int, 10)
    fmt.Println(c3)
    go fibonacci(cap(c3), c3)
    for i := range c3 {
        fmt.Println(i)
    }

    fmt.Println("-----------select-----------")
    // select
    c4 := make(chan int)
    quit := make(chan int)
    go func() {
        for i := 0; i < 10; i++ {
            fmt.Println(<-c4)
        }
        quit <- 0
    }()
    fibonacci2(c4, quit)

    /*
    默认选择
    当 select 中的其他条件分支都没有准备好的时候，`default` 分支会被执行。

    为了非阻塞的发送或者接收，可使用 default 分支：

    select {
    case i := <-c:
        // 使用 i
    default:
        // 从 c 读取会阻塞
    }
    */  
    fmt.Println("-----------阻塞-----------")
    tick := time.Tick(100 * time.Millisecond)
    boom := time.After(500 * time.Millisecond)
    for {
        select {
        case <-tick:
            fmt.Println("tick.")
        case <-boom:
            fmt.Println("BOOM!")
            return
        default:
            fmt.Println("    .")
            time.Sleep(50 * time.Millisecond)
        }
    }

    /*
练习：等价二叉树
可以用多种不同的二叉树的叶子节点存储相同的数列值。例如，这里有两个二叉树保存了序列 1，1，2，3，5，8，13。


用于检查两个二叉树是否存储了相同的序列的函数在多数语言中都是相当复杂的。这里将使用 Go 的并发和 channel 来编写一个简单的解法。

这个例子使用了 tree 包，定义了类型：

type Tree struct {
    Left  *Tree
    Value int
    Right *Tree
}

练习：等价二叉树
1. 实现 Walk 函数。

2. 测试 Walk 函数。

函数 tree.New(k) 构造了一个随机结构的二叉树，保存了值 `k`，`2k`，`3k`，...，`10k`。 创建一个新的 channel ch 并且对其进行步进：

go Walk(tree.New(1), ch)
然后从 channel 中读取并且打印 10 个值。应当是值 1，2，3，...，10。

3. 用 Walk 实现 Same 函数来检测是否 t1 和 t2 存储了相同的值。

4. 测试 Same 函数。

`Same(tree.New(1), tree.New(1))` 应当返回 true，而 `Same(tree.New(1), tree.New(2))` 应当返回 false。

{
    package main

    import "code.google.com/p/go-tour/tree"

    // Walk 步进 tree t 将所有的值从 tree 发送到 channel ch。
    func Walk(t *tree.Tree, ch chan int)

    // Same 检测树 t1 和 t2 是否含有相同的值。
    func Same(t1, t2 *tree.Tree) bool

    func main() {
    }

}


练习：Web 爬虫
在这个练习中，将会使用 Go 的并发特性来并行执行 web 爬虫。

修改 Crawl 函数来并行的抓取 URLs，并且保证不重复。

{
    
   package main

    import (
        "fmt"
    )

    type Fetcher interface {
        // Fetch 返回 URL 的 body 内容，并且将在这个页面上找到的 URL 放到一个 slice 中。
        Fetch(url string) (body string, urls []string, err error)
    }

    // Crawl 使用 fetcher 从某个 URL 开始递归的爬取页面，直到达到最大深度。
    func Crawl(url string, depth int, fetcher Fetcher) {
        // TODO: 并行的抓取 URL。
        // TODO: 不重复抓取页面。
        // 下面并没有实现上面两种情况：
        if depth <= 0 {
            return
        }
        body, urls, err := fetcher.Fetch(url)
        if err != nil {
            fmt.Println(err)
            return
        }
        fmt.Printf("found: %s %q\n", url, body)
        for _, u := range urls {
            Crawl(u, depth-1, fetcher)
        }
        return
    }

    func main() {
        Crawl("http://golang.org/", 4, fetcher)
    }

    // fakeFetcher 是返回若干结果的 Fetcher。
    type fakeFetcher map[string]*fakeResult

    type fakeResult struct {
        body string
        urls []string
    }

    func (f fakeFetcher) Fetch(url string) (string, []string, error) {
        if res, ok := f[url]; ok {
            return res.body, res.urls, nil
        }
        return "", nil, fmt.Errorf("not found: %s", url)
    }

    // fetcher 是填充后的 fakeFetcher。
    var fetcher = fakeFetcher{
        "http://golang.org/": &fakeResult{
            "The Go Programming Language",
            []string{
                "http://golang.org/pkg/",
                "http://golang.org/cmd/",
            },
        },
        "http://golang.org/pkg/": &fakeResult{
            "Packages",
            []string{
                "http://golang.org/",
                "http://golang.org/cmd/",
                "http://golang.org/pkg/fmt/",
                "http://golang.org/pkg/os/",
            },
        },
        "http://golang.org/pkg/fmt/": &fakeResult{
            "Package fmt",
            []string{
                "http://golang.org/",
                "http://golang.org/pkg/",
            },
        },
        "http://golang.org/pkg/os/": &fakeResult{
            "Package os",
            []string{
                "http://golang.org/",
                "http://golang.org/pkg/",
            },
        },
    }
 
}
    */

}
