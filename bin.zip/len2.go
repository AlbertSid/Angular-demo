package main

import (
    "fmt"
    "math"
)
// import "code.google.com/p/go-tour/pic"


func main() {
    /*
指针
Go 具有指针。 指针保存了变量的内存地址。

类型 *T 是指向类型 T 的值的指针。其零值是 `nil`。

var p *int
& 符号会生成一个指向其作用对象的指针。

i := 42
p = &i
* 符号表示指针指向的底层的值。

fmt.Println(*p) // 通过指针 p 读取 i
*p = 21         // 通过指针 p 设置 i
这也就是通常所说的“间接引用”或“非直接引用”。

与 C 不同，Go 没有指针运算。
    */
    i, j := 42, 2701

    p := &i         // point to i
    fmt.Println(*p) // 通过指针 p 读取 i
    *p = 21         // 通过指针 p 设置 i
    fmt.Println(i)  // see the new value of i

    p = &j         // point to j
    *p = *p / 37   // divide j through the pointer
    fmt.Println(j) // see the new value of j

    /*
    结构体
    一个结构体（`struct`）就是一个字段的集合。

    （而 type 的含义跟其字面意思相符。）
    */
    type Vertex struct {
        X int
        Y int
    }
    fmt.Println(Vertex{1, 2})

    v := Vertex{2, 3}
    v.X = 4//结构体字段使用点号来访问。
    fmt.Println(v.X)

    /*
    结构体指针
    结构体字段可以通过结构体指针来访问。

    通过指针间接的访问是透明的。
    */
    v2 := Vertex{1, 2}
    p2 := &v2
    p2.X = 1e9
    fmt.Println(v2)
    /*
    结构体文法
    结构体文法表示通过结构体字段的值作为列表来新分配一个结构体。

    使用 Name: 语法可以仅列出部分字段。（字段名的顺序无关。）

    特殊的前缀 & 返回一个指向结构体的指针。
    */
    var (
        vv1 = Vertex{1, 2}  // 类型为 Vertex
        vv2 = Vertex{X: 1}  // Y:0 被省略
        vv3 = Vertex{}      // X:0 和 Y:0
        pv  = &Vertex{1, 2} // 类型为 *Vertex
    )
    fmt.Println(vv1, pv, vv2, vv3)

    /*
数组
类型 [n]T 是一个有 n 个类型为 T 的值的数组。

表达式

var a [10]int
定义变量 a 是一个有十个整数的数组。

数组的长度是其类型的一部分，因此数组不能改变大小。 这看起来是一个制约，但是请不要担心； Go 提供了更加便利的方式来使用数组。
    */
    var a [2]string
    a[0] = "Hello"
    a[1] = "World"
    fmt.Println(a[0], a[1])
    fmt.Println(a)

    /*
slice
一个 slice 会指向一个序列的值，并且包含了长度信息。

[]T 是一个元素类型为 T 的 slice

    */
    pp := []int{2, 3, 5, 7, 11, 13}
    fmt.Println("p ==", pp)

    for i := 0; i < len(pp); i++ {
        fmt.Printf("p[%d] == %d\n", i, pp[i])
    }
    /*
对 slice 切片
slice 可以重新切片，创建一个新的 slice 值指向相同的数组。

表达式

s[lo:hi]
表示从 lo 到 hi-1 的 slice 元素，含两端。因此

s[lo:lo]
是空的，而

s[lo:lo+1]
有一个元素。
    */
    pi := []int{2, 3, 5, 7, 11, 13}
    fmt.Println("p ==", pi)
    fmt.Println("p[1:4] ==", pi[1:4])

    // 省略下标代表从 0 开始
    fmt.Println("p[:3] ==", pi[:3])

    // 省略上标代表到 len(s) 结束
    fmt.Println("p[4:] ==", pi[4:])


    /*
构造 slice
slice 由函数 make 创建。这会分配一个零长度的数组并且返回一个 slice 指向这个数组：

a := make([]int, 5)  // len(a)=5
为了指定容量，可传递第三个参数到 `make`：

b := make([]int, 0, 5) // len(b)=0, cap(b)=5

b = b[:cap(b)] // len(b)=5, cap(b)=5
b = b[1:]      // len(b)=4, cap(b)=4
    */
    ia := make([]int, 5)
    printSlice("a", ia)
    ib := make([]int, 0, 5)
    printSlice("b", ib)
    ic := ib[:2]
    printSlice("c", ic)
    id := ic[2:5]
    printSlice("d", id)



    /*
nil slice
slice 的零值是 `nil`。

一个 nil 的 slice 的长度和容量是 0。
    */
    var z []int
    fmt.Println(z, len(z), cap(z))
    if z == nil {
        fmt.Println("nil!")
    }

    /*
向 slice 添加元素
向 slice 添加元素是一种常见的操作，因此 Go 提供了一个内建函数 `append`。 内建函数的文档对 append 有详细介绍。

func append(s []T, vs ...T) []T
append 的第一个参数 s 是一个类型为 T 的数组，其余类型为 T 的值将会添加到 slice。

append 的结果是一个包含原 slice 所有元素加上新添加的元素的 slice。

如果 s 的底层数组太小，而不能容纳所有值时，会分配一个更大的数组。 返回的 slice 会指向这个新分配的数组。

    */
    var a9 []int
    printSlice("a", a9)

    // append works on nil slices.
    a9 = append(a9, 0)
    printSlice("a", a9)

    // the slice grows as needed.
    a9 = append(a9, 1)
    printSlice("a", a9)

    // we can add more than one element at a time.
    a9 = append(a9, 2, 3, 4)
    printSlice("a", a9)

    /*
range
for 循环的 range 格式可以对 slice 或者 map 进行迭代循环。
    */

    var pow = []int{1, 2, 4, 8, 16, 32, 64, 128}
    for i, v := range pow {
        fmt.Printf("2**%d = %d\n", i, v)
    }
/*
range（续）
可以通过赋值给 _ 来忽略序号和值。

如果只需要索引值，去掉“, value”的部分即可。
*/
    pow2 := make([]int, 10)
    for i := range pow2 {
        pow2[i] = 1 << uint(i)
    }
    for _, value := range pow2 {
        fmt.Printf("%d\n", value)
    }
    //
    // pic.Show(Pic)

    /*
map
map 映射键到值。

map 在使用之前必须用 make 而不是 new 来创建；值为 nil 的 map 是空的，并且不能赋值。
    */
    
    type Vertex1 struct {
        Lat, Long float64
    }

    var m map[string]Vertex1
    m = make(map[string]Vertex1)
    m["Bell Labs"] = Vertex1{
        40.68433, -74.39967,
    }
    fmt.Println(m["Bell Labs"])
    fmt.Println(m)

    /*
map 的文法
map 的文法跟结构体文法相似，不过必须有键名。
    */

    type Vertex2 struct {
        Lat, Long float64
    }

    var m2 = map[string]Vertex2{
        "Bell Labs": Vertex2{
            40.68433, -74.39967,
        },
        "Google": Vertex2{
            37.42202, -122.08408,
        },
    }
    fmt.Println(m2)
    // 如果顶级的类型只有类型名的话，可以在文法的元素中省略键名。
    // type Vertex struct {
    //     Lat, Long float64
    // }

    // var m = map[string]Vertex{
    //     "Bell Labs": {40.68433, -74.39967},
    //     "Google":    {37.42202, -122.08408},
    // }



    /*
修改 map
在 map m 中插入或修改一个元素：

m[key] = elem
获得元素：

elem = m[key]
删除元素：

delete(m, key)
通过双赋值检测某个键存在：

elem, ok = m[key]
如果 key 在 m 中，`ok` 为 true 。否则， ok 为 `false`，并且 elem 是 map 的元素类型的零值。

同样的，当从 map 中读取某个不存在的键时，结果是 map 的元素类型的零值。
    */
    m3 := make(map[string]int)

    m3["Answer"] = 42
    fmt.Println("The value:", m3["Answer"])

    m3["Answer"] = 48
    fmt.Println("The value:", m3["Answer"])

    delete(m3, "Answer")

    fmt.Println("The value:", m3["Answer"])

    v4, ok4 := m3["Answer"]
    fmt.Println("The value:", v4, "Present?", ok4)





    /*函数值 函数也是值。*/

    hypot := func(x, y float64) float64 {
        return math.Sqrt(x*x + y*y)
    }

    fmt.Println(hypot(3, 4))

    /*
    函数的闭包
    Go 函数可以是闭包的。闭包是一个函数值，它来自函数体的外部的变量引用。 函数可以对这个引用值进行访问和赋值；换句话说这个函数被“绑定”在这个变量上。

    例如，函数 adder 返回一个闭包。每个闭包都被绑定到其各自的 sum 变量上。
    */
    pos, neg := adder(), adder()
    for i := 0; i < 10; i++ {
        fmt.Println(
            pos(i),
            neg(-2*i),
        )
    }
    // example
    f := fibonacci()
    for i := 0; i < 10; i++ {
        fmt.Println(f())
    }

    f2 := fibonacci2(10)
    fmt.Println("f2" , f2)


    fac := factorial(5);
    fmt.Println("fac", fac)
    




    
}


func printSlice(s string, x []int) {
    fmt.Printf("%s len=%d cap=%d %v\n", s, len(x), cap(x), x)
}

func adder() func(int) int {
    sum := 0
    return func(x int) int {
        sum += x
        return sum
    }
}



func factorial(x int) (total int){
    if x == 1 {
        total = 1;
    }else{
        total = x * factorial(x - 1);
    }
    return;
}

func fibonacci2(n int) int {
  if n < 2 {
   return n
  }
  return fibonacci2(n-2) + fibonacci2(n-1)
}

func fibonacci() func() int {
    a,b := 0, 1
    return func() int {
        a,b = b,a+b
        return a
    }
}


// func Pic(dx, dy int) [][]uint8 {
//     //实现 `Pic`。它返回一个 slice 的长度 `dy`，和 slice 中每个元素的长度的 8 位无符号整数 `dx`。
// }



// package main

// import (
//     "code.google.com/p/go-tour/wc"
// )

// func WordCount(s string) map[string]int {
//     return map[string]int{"x": 1}
// }

// func main() {
//     wc.Test(WordCount)
// }