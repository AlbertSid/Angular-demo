

export default class Button {
    constructor() {
        super();
        this.styles = {
            button: {
                margin: 0.05,
                height: 0.4,
                backgroundColor: 'red',
            },
            text: {
                fontSize: 0.3,
                textAlign: 'center',
            },
        };
    }

    render() {
        return this.styles;
    }
}