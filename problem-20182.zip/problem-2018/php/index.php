<?php


if(@fopen($url, 'r')) {
    echo '文件存在';
} else {
    echo '文件不存在';
}


// filemtime ( string filename )

// 返回文件上次被修改的时间，出错时返回 FALSE。时间以 Unix 时间戳的方式返回，可用于 date()。

// 例如：$a=filemtime("log.txt");
//            echo "修改时间：".date("Y-m-d H:i:s",$a)."

// filectime ( string filename )

// 返回文件上次 inode 被修改的时间，如果出错则返回 FALSE。时间以 Unix 时间戳的方式返回。

// 例如：$a=filectime("log.txt");
//            echo "创建时间：".date("Y-m-d H:i:s",$a)."

// fileatime ( string filename )

// 返回文件上次被访问的时间，如果出错则返回 FALSE。时间以 Unix 时间戳的方式返回。

// 例如：$a=fileatime("log.txt");
//           echo "修改时间：".date("Y-m-d H:i:s",$a)."



//opJSON


$json = 'xxx.json';
if(is_file($json) && !empty(file_get_contents($json))){
	$cont = json_decode(file_get_contents($json), $assoc_array = false );
}else{
	//file_get_contents()
	//preg_replace_callback($reg,callback)
	//file_put_contents()
}



//str_replace()
//




function deldirs($dir) {
	// if(is_dir($dir)){
	// 	if($dh=opendir($dir)){
	// 		while(($file = readdir($dh))!==false){
	// 			if(in_array($file,['.','..'])) contiune;
	// 			$filepath = './'.$file
	// 			if(!is_dir($filepath)){
	// 				unlink($filepath)
	// 			}else{

	// 			}
	// 		}
	// 		closedir($dh)
	// 		if(rmdir($dir)){
	// 			return true
	// 		}
	// 	}
	// }
  //先删除目录下的文件：
  $dh=opendir($dir);
  while ($file=readdir($dh)) {
    if($file!="." && $file!="..") {
      $fullpath=$dir."/".$file;
      if(!is_dir($fullpath)) {
          unlink($fullpath);
      } else {
          deldirs($fullpath);
      }
    }
  }
 
  closedir($dh);
  //删除当前文件夹：
  if(rmdir($dir)) {
    return true;
  } else {
    return false;
  }
}


$startdate="2011-3-15 11:50:00";

$enddate="2012-12-12 12:12:12";

$date=floor((strtotime($enddate)-strtotime($startdate))/86400);

$hour=floor((strtotime($enddate)-strtotime($startdate))%86400/3600);

$minute=floor((strtotime($enddate)-strtotime($startdate))%86400/60);

$second=floor((strtotime($enddate)-strtotime($startdate))%86400%60);

echo $date."天<br>";

echo $hour."小时<br>";

echo $minute."分钟<br>";

echo $second."秒<br>";












?>
