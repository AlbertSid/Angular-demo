//index.js
require("babel-register");
// require('./server1.js')
require('./server2.js')