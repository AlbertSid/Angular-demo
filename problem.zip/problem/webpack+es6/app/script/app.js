import _ from 'lodash';

import bar from './router/bar.js';
import print from './content/print.js';

import './../styles/index.css';
import test from './../images/test.jpeg';

console.log(1223)
bar();
print();

function component() {
    var element = document.createElement('div');
    element.innerHTML = _.join(['Hello', 'webpack'], ' ');
    element.classList.add('hello');

    var myIcon = new Image();
    myIcon.src = test;

    element.appendChild(myIcon);

    return element;
}

let element = component(); 
document.body.appendChild(element);

if (module.hot) {
    module.hot.accept('./content/print.js', function() {
        console.log('Accepting the updated print module!');
        document.body.removeChild(element);
		element = component();
		document.body.appendChild(element);
    })
} 




// import React from 'react'
// import ReactDOM from 'react-dom'
// import { AppContainer } from 'react-hot-loader'
// import App from './containers/App'


// const render = Component => {
//   ReactDOM.render(
//   	<AppContainer>
//       <Component />
//     </AppContainer>,
//     document.getElementById('root'),
//   )
// }

// render(App)

// // Webpack Hot Module Replacement API
// if (module.hot) {
//   module.hot.accept('./containers/App', () => { render(App) })
// }