# coding: utf-8

import os
import svn.local
import svn.remote


class SVN:

    def __init__(self, admin):
        self.local_version = None
        self.remote_version = None
        self.diffList = []
        self.username = admin['user']
        self.password = admin['psd']

    def getVersion(self, local_path, remote_path):
        local = svn.local.LocalClient(local_path)
        remote = svn.remote.RemoteClient(remote_path)
        self.local_version = local.info()['commit_revision']
        self.remote_version = remote.info()['commit_revision']
        self.diffList = remote.diff_summary(
            self.local_version, self.remote_version)

    def checkout(self, local_path, remote_path):
        try:
            if not os.path.exists(local_path):
                os.makedirs(local_path)
                os.system('svn checkout %s --username %s --password %s %s' % (remote_path, self.username, self.password, local_path))
            self.getVersion(local_path, remote_path)
        except(Exception, e):
            pass

        if self.local_version != self.remote_version:
            os.system('svn revert -R %s' % local_path)
            sty = 'svn update %s' % local_path
            os.system(sty)
            # 本地是否有冲突
            read = os.popen('svn st %s' % local_path)
            lines = read.readlines()
            for line in lines:
                line = line.strip('\r\n')
                if line.startswith('C', 0, 1):
                    os.remove(line[1:].strip())
                    os.system(sty)

    def onelist(self, local_path, isMore=False):
        lq = svn.local.LocalClient(local_path)
        if isMore:
            return lq.list(extended=True)
        else:
            return lq.list()

    def treelist(self, local_path):
        lq = svn.local.LocalClient(local_path)
        file_list = []
        dir_list = []
        for file, dir in lq.list_recursive():
            file_list.append(file)
            dir_list.append(dir)
        return file_list, dir_list


# admin = {
#     'user': '123',
#     'psd': 'qwe'
# }

# svn = SVN(admin)
