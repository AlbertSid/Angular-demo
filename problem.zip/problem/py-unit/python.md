## python

[python-websocket](http://letus.club/2016/04/10/python-websocket/)
[WebSocket-for-Python](https://github.com/Lawouach/WebSocket-for-Python)
[python.jobbole](http://python.jobbole.com/)

[flask+Redis实现简单消息队列](https://www.jianshu.com/p/9c04890615ba)
[Flask例子-实现Redis Task Queue（任务队列）](https://python.freelycode.com/contribution/detail/124)
[深入flask之异步非堵塞实现](http://blog.csdn.net/danny_amos/article/details/50859383)
[Flask实现异步非阻塞请求功能](http://blog.csdn.net/yannanxiu/article/details/52915929)
[flask单线程传输流媒体阻塞](http://blog.csdn.net/u012689961/article/details/50410221)
[Asynchrony in the Flask](http://sergray.me/asynchony-in-the-flask.html)
[Flask 阻塞的问题](https://segmentfault.com/q/1010000004501782)
[python web 部署：nginx + gunicorn + supervisor + flask 部署笔记](https://www.jianshu.com/p/be9dd421fb8d)
[异步任务神器 Celery 简明笔记](https://www.jianshu.com/p/1840035cb510)

[深入理解 Python 异步编程(上)](http://python.jobbole.com/88291/)
[Python并发编程之协程/异步IO](https://www.ziwenxie.site/2016/12/19/python-asyncio/)
[最新Python异步编程详解](https://www.jianshu.com/p/b036e6e97c18)

[Numpy 小结](http://python.jobbole.com/88860/)