https://codepen.io/erikjung/pen/XdWEKE
https://codepen.io/mandymichael/pen/KZeKGX
https://codepen.io/giana/pen/JGdbje
https://codepen.io/ani_davtyan/pen/KZoKmQ
https://codepen.io/ainalem/pen/zpLQEx

[nativefier](https://github.com/jiahaog/nativefier)
[神经网络与深度学习-英文版](http://neuralnetworksanddeeplearning.com/)
[awesome-python-cn](https://github.com/jobbole/awesome-python-cn#%E6%96%87%E6%A1%A3)
[Web API 文档生成工具 apidoc](https://segmentfault.com/a/1190000012946141) - [apidocjs](http://apidocjs.com/#demo)

[从浏览器多进程到JS单线程，JS运行机制最全面的一次梳理](https://segmentfault.com/a/1190000012925872)
[js在微信、微博、QQ、Safari唤起App的解决方案](https://segmentfault.com/a/1190000012940046)
[通讯方式](https://segmentfault.com/a/1190000012948613)
[静态网站生成-了不起的 Gatsby.js](https://segmentfault.com/a/1190000012960139)
[深度解析`create-react-app`源码](https://segmentfault.com/a/1190000012952498)
[fastdom](https://github.com/wilsonpage/fastdom)

[下一代通信协议：QUIC](https://knownsec-fed.com/2018-01-19-xia-yi-dai-tong-xin-xie-yi-quic/)
[(a==1 && a==2 && a==3)能输出ture么？](https://segmentfault.com/a/1190000012921114)

[JS-total](https://github.com/laihuamin/JS-total)

[es5规范](http://yanhaijing.com/es5/#about)

[某天博客](https://knownsec-fed.com/)
[前端框架比较](https://javascriptreport.com/the-ultimate-guide-to-javascript-frameworks/)

[从浏览器多进程到JS单线程，JS运行机制最全面的一次梳理](https://segmentfault.com/a/1190000012925872)
[cssday](https://cssday.nl/2018)




## Shell脚本编程
[Shell脚本编程30分钟入门](https://github.com/qinjx/30min_guides/blob/master/shell.md)
[Shell 教程](http://www.runoob.com/linux/linux-shell.html)
[如何系统地学习Shell编程？](https://www.zhihu.com/question/28377046)


