1. `npm install`

2. 确认index引入的是server1. 在`node index.js` ，接着 新开一个指令窗口，输入 `curl -XPOST http://localhost:3000/graphql`  得到 `Hello!`

3. 确认index引入的是server2. 在`node index.js` , 确认server2引入schema1 输入 `curl -XPOST -H "Content-Type:application/graphql"  -d 'query RootQueryType { count }' http://localhost:3000/graphql` 得到 
```
{
  "data": {
    "count": 0
  }
}
```

输入`curl -XPOST -H 'Content-Type:application/graphql'  -d '{ count }' http://localhost:3000/graphql` 同理


4. 请求`curl -XPOST -H 'Content-Type:application/graphql'  -d '{__schema { queryType { name, fields { name, description} }}}' http://localhost:3000/graphql` 得到
```
{
  "data": {
    "__schema": {
      "queryType": {
        "name": "RootQueryType",
        "fields": [
          {
            "name": "count",
            "description": null
          }
        ]
      }
    }
  }
}
```

5. 在`schema1.js`中添加`description: 'The count!',` 之后在输入`curl -XPOST -H 'Content-Type:application/graphql'  -d '{__schema { queryType { name, fields { name, description} }}}' http://localhost:3000/graphql` 得到 
```
{
  "data": {
    "__schema": {
      "queryType": {
        "name": "RootQueryType",
        "fields": [
          {
            "name": "count",
            "description": "The count!" //注意这里变了
          }
        ]
      }
    }
  }
}
```

6. 在确认server2引入schema2. 之后输入`curl -XPOST -H 'Content-Type:application/graphql' -d 'mutation RootMutationType { updateCount }' http://localhost:3000/graphql` =>
```
{
  "data": {
    "updateCount": 1
  }
}
```
输入`curl -XPOST -H 'Content-Type:application/graphql' -d '{ count }' http://localhost:3000/graphql` => 
```
{
  "data": {
    "count": 1
  }
}
```


github: `https://github.com/clayallsopp/graphql-intro`