export default function bar() {
  console.log('bar')
}