# 关于感情、

[现在的男性是否普遍不再对女性展开追求了？为什么？](https://www.zhihu.com/question/55744630)
<!-- [为什么现在男生普遍不追求女生了？](http://lady.163.com/17/0301/10/CEEFE3TS00267VA9.html) -->
[现在的女性是否普遍不再对男性展开追求了？为什么？](https://www.zhihu.com/question/55832978?sort=created)
[为什么现在的男性普遍不再追求女生了？](http://eladies.sina.com.cn/feel/xinli/2017-09-01/0913/doc-ifykqmrv5650523.shtml)
[为什么现在男性普遍不再追求女性了?他们都去干嘛了？](http://jiangsu.china.com.cn/html/jsnews/bwzh/9374625_1.html)





