#!/usr/bin/env node

console.log(1)