const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin'); 
const CleanWebpackPlugin = require('clean-webpack-plugin');
var ManifestPlugin = require('webpack-manifest-plugin');


const path = require('path');
const dist = path.resolve(__dirname, 'dist');


module.exports = {
    //插件项
    //页面入口文件配置
    // entry: [
    //     'babel-polyfill',
    //     'react-hot-loader/patch',
    //     './app/script/app.js'
    // ],
    entry: {
        output_name: './app/script/app.js'
        // ---------
        // pageOne: './src/pageOne/index.js',
        // pageTwo: './src/pageTwo/index.js',
        // pageThree: './src/pageThree/index.js'
    },
    //入口文件输出配置
    output: {
        // publicPath
        path: dist,
        filename: 'bundle.js', // [name].bundle.js => output_name.bundle.js
        publicPath: '/'
    },
    devtool: 'inline-source-map',
    module: {
        rules: [{
                test: /\.css$/,
                // use: ['style-loader', 'css-loader']
                use: [
                    { loader: 'style-loader' },
                    {
                        loader: 'css-loader',
                        options: {
                            modules: false
                        }
                    }
                ]
            },
            // {
            //     test: /\.(js|jsx)?$/,
            //     use: ['react-hot-loader/webpack']
            // },
            {
                test: /\.(png|svg|jpg|gif|jpeg)$/,
                use: ['file-loader']
            },
            {
                test: /\.(woff|woff2|eot|ttf|otf)$/,
                use: ['file-loader']
            }
        ]
    },
    plugins: [
        // new ManifestPlugin(options)
        // new webpack.optimize.UglifyJsPlugin(),
        new CleanWebpackPlugin(['dist']),
        new HtmlWebpackPlugin({ title: 'Output Management' }),
        new webpack.NamedModulesPlugin(),
        new webpack.HotModuleReplacementPlugin()
    ],
    //其它解决方案配置
    resolve: {
        // root: 'E:/github/flux-example/src', //绝对路径
        // extensions: ['', '.js', '.json', '.scss'],
        // alias: {
        //     AppStore: 'js/stores/AppStores.js',
        //     ActionType: 'js/actions/ActionType.js',
        //     AppAction: 'js/actions/AppAction.js'
        // }
    },
    devServer: {
        contentBase: './dist',
        // host: 'localhost',
        // compress: true,
        // port: 9090,
        hot: true
    }
};