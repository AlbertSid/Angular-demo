'use strict';
let gulp = require('gulp');
let babel = require('gulp-babel');
// 获取 uglify 模块（用于压缩 JS）
let uglify = require('gulp-uglify');
let rename = require('gulp-rename');
/**
 * 编译js文件
 */
function es6(callback) {
    return gulp.src(['./ec-do-2.0.0.js'])
        .pipe(babel({
            presets: ['es2015']
        }))
        .pipe(gulp.dest('./dist'))
        .pipe(rename({ suffix: '.min' }))
        .pipe(uglify())
        .pipe(gulp.dest('./dist'))
        .on('end', function() {
            callback ? callback() : null
            console.log('es6 success')
        })
}

function test(callback) {
    return gulp.src(['./test-es6.js'])
        .pipe(babel({
            presets: ['es2015']
        }))
        .pipe(gulp.dest('./dist'))
        .pipe(rename({ suffix: '.min' }))
        .pipe(uglify())
        .pipe(gulp.dest('./dist'))
        .on('end', function() {
            callback ? callback() : null
            console.log('test success')
        })
}
async function build() {
    console.log('start')
    await new Promise(function(resolve, reject) {
        console.log(0.1)
        es6(resolve)
        console.log(0.2)
    }).then(function(){
    	console.log('promise 1 end')
    })
    console.log(1)
    await new Promise(function(resolve, reject) {
        console.log(2.1)
        test(resolve)
        console.log(2.2)
    }).then(function(){
    	console.log('promise 2 end')
    })
    console.log('end')
}

function build2(callback) {
    console.log('start')
    return Promise.all([
    	new Promise(function(resolve, reject) {
	        console.log(0.1)
	        es6(resolve)
	        console.log(0.2)
	    }).then(function(){
	    	console.log('promise 3 end')
	    }),
	    new Promise(function(resolve, reject) {
	        console.log(2.1)
	        test(resolve)
	        console.log(2.2)
    	}).then(function(){
	    	console.log('promise 4 end')
	    })
	]).then(callback)
    console.log('end')
}


gulp.task('es6-js', es6);
/**
 * 运行任务
 */
gulp.task('default', [], async function() {
    console.log('-----------------')
    console.log('同步执行')
    await build()
    console.log('并发执行')
    await build2(function(){
    	console.log('build2 callback')
    })
    console.log('---------watch--------')
    gulp.watch('ec-do-2.0.0.js', ['es6-js']);
});