/* 
 *
 * 
 *
 */

import 'babel-core/register';
import 'babel-polyfill';
import  Button from 'button.js';


(async function task() {
	var but = new Button();
    console.log(1235)
    var d = await new Promise(function(resolve, reject) {
        setTimeout(function() {
            resolve(12342354)
        }, 1000)
    });
    console.log(d)
    console.log(but)
})()