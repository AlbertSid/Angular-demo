## What is this issue about?
>  Mark all the applicable options and give a brief description for each of them.
- [ ] It a request to add a new feature/content.
>  Description here.
- [ ] It suggests modifications in the existing content.
>  Description here.
- [ ] Want to discuss about some feature/content.
>  Description here.
- [ ] Something else.
>  Description here.
