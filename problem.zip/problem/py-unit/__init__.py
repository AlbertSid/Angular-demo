# coding: utf-8

import hashlib
import os
import shutil
import time
import json
from platform import system


class Unit:

    def __init__(self):
        self.ROOR_PATH = os.path.dirname(__file__)
        self.systemTpye = 'mac' if 'darwin' in system().lower() else 'win'

    def writejson(self, file, data):
        with open(file, 'w') as f:
            f.write(json.dumps(data, ensure_ascii=False))

    def readjson(self, file):
        with open(file) as f:
            return json.load(f)

    def change_file_content(self, file, target, newtext):
        with open(file, mode='r') as f:
            lines = f.readlines()
            for index, line in enumerate(lines):
                line = line.strip()
                if len(line) == 0:
                    continue

                isIn = (target[0] in line) and (
                    target[1] in line) and (target[2] in line)
                if isIn:
                    ary1 = line.split(target[1])
                    ary1 = ary1[1].split(target[2])
                    lines[index] = ary1[0] + target[1] + \
                        newtext + target[2] + ary2[1] + '\n'

        with open(file, mode='w') as fo:
            for i in lines:
                fo.write(i)

    def uid(self, strs=None):
        m = hashlib.md5()
        m.update(bytes(str(strs if strs != None else time.clock()), encoding='utf-8'))
        return m.hexdigest()

    def copyFile(self, from_url, to_url, rename=None):
        if not os.path.exists(from_url):
            return
        for file in os.listdir(from_url):
            sourceFile = os.path.join(from_url, file)
            targetFile = os.path.join(from_url, rename)

            if os.path.isfile(sourceFile):
                shutil.copy2(sourceFile, targetFile)

    def copydirs(self, from_url, to_url):
        if not os.path.exists(from_url):
            return
        for file in os.listdir(from_url):
            sourceFile = os.path.join(from_url, file)
            targetFile = os.path.join(from_url, file)
            if os.path.isfile(sourceFile):
                if not os.path.exists(from_url):
                    os.makedirs(from_url)
                if not os.path.exists(targetFile) or (os.path.exists(targetFile) and os.path.getsize(targetFile) != os.path.getsize(sourceFile)):
                    shutil.copy2(sourceFile, targetFile)
                    # open(targetFile,"wb").write(open(sourceFile,'rb').read())
                    # shutil.copy(sourceFile,targetFile)
                    # shutil.copyfile(sourceFile,targetFile)

            if os.path.isdir(sourceFile):
                os.mkdir(targetFile)
                self.copydirs(sourceFile, targetFile)

    def fileList(self, dirs):
        list = []
        for root, dirs, files in os.walk(dirs):
            dict = {}
            dict['path'] = root
            dict['file'] = files
            list.append(dict)
        return list


unit = Unit()
