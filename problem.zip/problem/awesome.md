 
# 自己收集的一些项目地址
[json-server](https://github.com/typicode/json-server)
[VoxelSpace](https://github.com/s-macke/VoxelSpace.git)
[awesome-python](https://github.com/vinta/awesome-python.git)
[python-react-v8](https://github.com/nitely/python-react-v8.git)

[awesome-php](https://github.com/ziadoz/awesome-php.git)

[awesome-go](https://github.com/avelino/awesome-go.git)
[beego](https://github.com/astaxie/beego.git)
[cache2go](https://github.com/muesli/cache2go.git)
[camlistore](https://github.com/camlistore/camlistore.git)
[gogs](https://gitee.com/Unknown/gogs.git)
[golang-open-source-projects](https://github.com/hackstoic/golang-open-source-projects.git)
[mindoc](https://github.com/lifei6671/mindoc.git)
[moby](https://github.com/moby/moby.git)
[negroni](https://github.com/urfave/negroni.git)
[rpcx](https://gitee.com/mirrors/rpcx.git)
 
[awesome-javascript](https://github.com/sorrycc/awesome-javascript.git)
[awesome-javascript-cn](https://github.com/jobbole/awesome-javascript-cn.git)
[Front-End-Checklist](https://github.com/thedaviddias/Front-End-Checklist.git)
[phantomjs]()
[js-framework-benchmark](https://github.com/krausest/js-framework-benchmark)

[awesome-graphql](https://github.com/chentsulin/awesome-graphql)



[awesome-css-cn](https://github.com/jobbole/awesome-css-cn.git)
[awesome-css-en](https://github.com/sotayamashita/awesome-css.git)
[awesome-css-en-1](https://github.com/ikkou/awesome-css.git)
[awesome-css-en-2](https://github.com/dennysjmarquez/awesome-css.git)
[awesome-css-in-js](https://github.com/tuchk4/awesome-css-in-js.git)
[scut](https://github.com/davidtheclark/scut.git)



## V8
[v8](https://github.com/v8/v8.git)
[v8-0.1.5](https://github.com/v8/v8/releases/tag/0.1.5)
[v8-0.1.5](https://github.com/v8/v8/tree/3a1ab8c626dfee28a5cafb6632b28e284c4cffb3)
[认识 V8 引擎](https://zhuanlan.zhihu.com/p/27628685)

## 手册
[前端工程师手册](https://leohxj.gitbooks.io/front-end-database/content/html-and-css-basic/index.html)
[前端开发规范](https://www.w3cschool.cn/webdevelopment/)

## AI
[tutorial](https://github.com/KeKe-Li/tutorial.git)
[AiLearning](https://github.com/geekhoo/AILearning)
[入门机器学习](https://segmentfault.com/a/1190000012432435)
[tensorflow-tutorial-samples](https://github.com/gzdaijie/tensorflow-tutorial-samples)

## VR
[earth-moon-vr](https://github.com/eh3rrera/earth-moon-vr.git)