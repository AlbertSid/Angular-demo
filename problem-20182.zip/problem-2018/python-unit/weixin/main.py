# -*- coding: utf-8 -*-
from wechatpy.utils import check_signature
from wechatpy.exceptions import InvalidSignatureException

try:
    check_signature(token, signature, timestamp, nonce)
except InvalidSignatureException:
    # 处理异常情况或忽略
    pass


from wechatpy import parse_message
from wechatpy.crypto import WeChatCrypto
from wechatpy.exceptions import InvalidSignatureException, InvalidAppIdException

crypto = WeChatCrypto(token, encoding_aes_key, appid)
try:
    decrypted_xml = crypto.decrypt_message(
        xml,
        msg_signature,
        timestamp,
        nonce
    )
except (InvalidAppIdException, InvalidSignatureException):
    # 处理异常或忽略
    pass

msg = parse_message(decrypted_xml)